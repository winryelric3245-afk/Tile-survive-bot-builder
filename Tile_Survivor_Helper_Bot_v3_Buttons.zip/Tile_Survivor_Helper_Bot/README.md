
# Tile Survivor Build & Research Helper Bot

A ready-to-run Discord bot for tracking long Tile Survivor construction and research timers.

## What it does

- `/addbuild` — add a construction timer.
- `/addresearch` — add a research timer.
- `/helpers` — show the current priority list.
- `/updatetime` — replace the remaining time on one of your own timers.
- `/editimer` — edit your timer's player name, type, project, or remaining time.
- `/timers` — privately show every active timer.
- `/done` — mark a timer complete.
- `/remove` — delete a timer.
- `/board` — create one persistent auto-updating helper board in the current channel.
- `/seedcurrent` — load the supplied 9/10/2026 starting list.

The helper board only displays:
- Builds with **more than 10 days remaining**
- Research with **more than 7 days remaining**

As the timers count down, players automatically fall off the helper-priority board once they are below the threshold.

The board edits itself every 10 minutes, and Discord's relative timestamps (`ends in ...`) update on the client too.

## Included 9/10 starting list

`/seedcurrent` loads:

Construction:
- B3ndm3ov3r — 11 days — Power Plant
- Tomcat — 24 days — Power Plant
- GabrielValeriote — 14 days — Power Plant
- Kickflip — 19 days — Power Plant
- Advent — 18 days — Power Plant
- Winry — 22 days — Construction

Research:
- Winry — 55 days — Research Timer 1
- Winry — 19 days — Research Timer 2

The seed snapshot uses **September 10, 2026 at 10:41 AM Pacific** as the starting time.

## Discord setup

1. Go to the Discord Developer Portal.
2. Create a **New Application**.
3. Open **Bot** and create/add the bot.
4. Copy/reset the bot token. Never post this token in Discord or share it.
5. In **OAuth2 > URL Generator**, select:
   - `bot`
   - `applications.commands`
6. Bot permissions:
   - View Channels
   - Send Messages
   - Embed Links
   - Read Message History
7. Open the generated invite URL and add the bot to your server.

You do **not** need Message Content Intent for this bot.

## Install / run

Requires Python 3.10+ recommended.

### Windows

1. Install Python.
2. Extract this folder.
3. Rename `.env.example` to `.env`.
4. Paste your token after `DISCORD_TOKEN=`.
5. Optionally put your server ID after `GUILD_ID=` so slash commands sync immediately.
6. Double-click `start_windows.bat`.

### Mac / Linux

```bash
cp .env.example .env
# edit .env and add your token
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python bot.py
```

## First commands in Discord

Run:

1. `/seedcurrent`
2. `/board`

After that, members can add new timers with:

`/addbuild player:Tomcat days:24 project:Power Plant`

or:

`/addresearch player:Winry days:55 project:Season Research`

You can also include hours/minutes.

## Keeping it online 24/7

The bot only auto-updates while the Python process is running. For 24/7 use, run it on an always-on computer, VPS, or a Python-compatible hosting service.

The SQLite database is stored in `helper_bot.db`. Back up that file if you move hosts.

## Adjust thresholds

Edit `.env`:

```env
BUILD_THRESHOLD_DAYS=10
RESEARCH_THRESHOLD_DAYS=7
REFRESH_MINUTES=10
```

Restart the bot afterward.


## Updating your own timer

Members can update timers they personally added.

Example:

`/updatetime timer_id:12 days:14 hours:6`

This replaces the old countdown with **14 days 6 hours remaining from right now**.

For a fuller edit:

`/editimer timer_id:12 project:Power Plant 6 days:18`

Members may edit only timers they created. Users with **Manage Server** or **Administrator** permission can edit any timer.

If a member's timer changes because Season Skill help reduced it, they should simply run `/updatetime` with their new remaining time.


## Simple buttons

The persistent helper board now has three buttons:

- **Add Build** — opens a simple form for player, build name, days, and hours.
- **Add Research** — opens the same simple form for research.
- **Edit My Timer** — shows the member's active timers in a dropdown; selecting one opens the edit form.

Regular members can add and edit their own timers directly from the board. Server managers can edit any active timer.

The slash commands are still available as a backup.
