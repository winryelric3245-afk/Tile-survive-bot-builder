
import os
import sqlite3
import asyncio
from datetime import datetime, timedelta, timezone

import discord
from discord import app_commands
from discord.ext import commands, tasks
from dotenv import load_dotenv

load_dotenv()

TOKEN = os.getenv("DISCORD_TOKEN")
GUILD_ID = os.getenv("GUILD_ID")
DB_PATH = os.getenv("DB_PATH", "helper_bot.db")
BUILD_THRESHOLD_DAYS = float(os.getenv("BUILD_THRESHOLD_DAYS", "10"))
RESEARCH_THRESHOLD_DAYS = float(os.getenv("RESEARCH_THRESHOLD_DAYS", "7"))
REFRESH_MINUTES = int(os.getenv("REFRESH_MINUTES", "10"))

intents = discord.Intents.default()


def connect():
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    return db


def init_db():
    with connect() as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS timers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id INTEGER NOT NULL,
                player TEXT NOT NULL,
                timer_type TEXT NOT NULL CHECK(timer_type IN ('build','research')),
                project TEXT NOT NULL,
                end_ts INTEGER NOT NULL,
                created_by INTEGER,
                created_ts INTEGER NOT NULL,
                completed INTEGER NOT NULL DEFAULT 0
            )
        """)
        db.execute("""
            CREATE TABLE IF NOT EXISTS boards (
                guild_id INTEGER PRIMARY KEY,
                channel_id INTEGER NOT NULL,
                message_id INTEGER NOT NULL
            )
        """)


def human_remaining(end_ts: int) -> str:
    seconds = max(0, end_ts - int(datetime.now(timezone.utc).timestamp()))
    days, rem = divmod(seconds, 86400)
    hours, rem = divmod(rem, 3600)
    minutes = rem // 60
    if days:
        return f"{days}d {hours}h"
    if hours:
        return f"{hours}h {minutes}m"
    return f"{minutes}m"


def qualifying_rows(guild_id: int):
    now = int(datetime.now(timezone.utc).timestamp())
    build_cutoff = now + int(BUILD_THRESHOLD_DAYS * 86400)
    research_cutoff = now + int(RESEARCH_THRESHOLD_DAYS * 86400)
    with connect() as db:
        builds = db.execute("""
            SELECT * FROM timers
            WHERE guild_id=? AND completed=0 AND timer_type='build' AND end_ts > ?
            ORDER BY end_ts DESC
        """, (guild_id, build_cutoff)).fetchall()
        research = db.execute("""
            SELECT * FROM timers
            WHERE guild_id=? AND completed=0 AND timer_type='research' AND end_ts > ?
            ORDER BY end_ts DESC
        """, (guild_id, research_cutoff)).fetchall()
    return builds, research


def all_active_rows(guild_id: int):
    now = int(datetime.now(timezone.utc).timestamp())
    with connect() as db:
        return db.execute("""
            SELECT * FROM timers
            WHERE guild_id=? AND completed=0 AND end_ts > ?
            ORDER BY timer_type, end_ts DESC
        """, (guild_id, now)).fetchall()


def make_board_embed(guild_id: int) -> discord.Embed:
    builds, research = qualifying_rows(guild_id)
    embed = discord.Embed(
        title="Build & Research Helper List",
        description=(
            f"Focus Season Skills on **builds over {BUILD_THRESHOLD_DAYS:g} days** "
            f"and **research over {RESEARCH_THRESHOLD_DAYS:g} days**.\n"
            "Timers count down automatically."
        ),
        timestamp=datetime.now(timezone.utc),
    )

    if builds:
        lines = [
            f"**#{r['id']} · {r['player']}** — {human_remaining(r['end_ts'])}\n"
            f"{r['project']} · ends <t:{r['end_ts']}:R>"
            for r in builds
        ]
        embed.add_field(name="Construction Priority", value="\n\n".join(lines)[:1024], inline=False)
    else:
        embed.add_field(name="Construction Priority", value="No qualifying build timers right now.", inline=False)

    if research:
        lines = [
            f"**#{r['id']} · {r['player']}** — {human_remaining(r['end_ts'])}\n"
            f"{r['project']} · ends <t:{r['end_ts']}:R>"
            for r in research
        ]
        embed.add_field(name="Research Priority", value="\n\n".join(lines)[:1024], inline=False)
    else:
        embed.add_field(name="Research Priority", value="No qualifying research timers right now.", inline=False)

    embed.set_footer(text=f"Auto-refresh every {REFRESH_MINUTES} min · Use the buttons below to add or edit timers")
    return embed


class TimerModal(discord.ui.Modal):
    def __init__(self, timer_type: str, edit_row=None):
        self.timer_type = timer_type
        self.edit_row = edit_row
        title = f"Edit {timer_type.title()} Timer" if edit_row else f"Add {timer_type.title()} Timer"
        super().__init__(title=title)

        self.player = discord.ui.TextInput(
            label="Player name",
            default=edit_row["player"] if edit_row else "",
            max_length=50,
        )
        self.project = discord.ui.TextInput(
            label="Build / Research",
            default=edit_row["project"] if edit_row else ("Power Plant" if timer_type == "build" else "Research"),
            max_length=80,
        )
        self.days = discord.ui.TextInput(
            label="Days remaining",
            placeholder="Example: 24",
            default="" if not edit_row else str(max(0, (edit_row["end_ts"] - int(datetime.now(timezone.utc).timestamp())) // 86400)),
            max_length=4,
        )
        self.hours = discord.ui.TextInput(
            label="Hours remaining (0-23)",
            placeholder="0",
            default="0",
            required=False,
            max_length=2,
        )
        self.add_item(self.player)
        self.add_item(self.project)
        self.add_item(self.days)
        self.add_item(self.hours)

    async def on_submit(self, interaction: discord.Interaction):
        try:
            days = int(self.days.value or 0)
            hours = int(self.hours.value or 0)
            if days < 0 or hours < 0 or hours > 23:
                raise ValueError
        except ValueError:
            await interaction.response.send_message("Enter valid days and hours (hours must be 0–23).", ephemeral=True)
            return

        now = datetime.now(timezone.utc)
        end_ts = int((now + timedelta(days=days, hours=hours)).timestamp())

        if self.edit_row:
            with connect() as db:
                db.execute(
                    """UPDATE timers SET player=?, project=?, timer_type=?, end_ts=?, completed=0 WHERE id=?""",
                    (self.player.value.strip(), self.project.value.strip(), self.timer_type, end_ts, self.edit_row["id"]),
                )
            msg = f"Updated **#{self.edit_row['id']} {self.player.value}** to **{days}d {hours}h** remaining."
        else:
            with connect() as db:
                cur = db.execute(
                    """INSERT INTO timers(guild_id, player, timer_type, project, end_ts, created_by, created_ts)
                       VALUES(?,?,?,?,?,?,?)""",
                    (
                        interaction.guild_id, self.player.value.strip(), self.timer_type,
                        self.project.value.strip(), end_ts, interaction.user.id, int(now.timestamp())
                    ),
                )
                timer_id = cur.lastrowid
            msg = f"Added **#{timer_id} {self.player.value}** — **{days}d {hours}h** remaining."

        await interaction.response.send_message(msg, ephemeral=True)
        await refresh_board(interaction.guild_id)


class EditTimerSelect(discord.ui.Select):
    def __init__(self, rows):
        options = []
        for r in rows[:25]:
            options.append(
                discord.SelectOption(
                    label=f"#{r['id']} {r['player']}"[:100],
                    description=f"{r['timer_type'].title()} · {human_remaining(r['end_ts'])}"[:100],
                    value=str(r["id"]),
                )
            )
        super().__init__(placeholder="Choose a timer to edit…", options=options)

    async def callback(self, interaction: discord.Interaction):
        timer_id = int(self.values[0])
        with connect() as db:
            row = db.execute(
                "SELECT * FROM timers WHERE id=? AND guild_id=?", (timer_id, interaction.guild_id)
            ).fetchone()
        if not row:
            await interaction.response.send_message("That timer no longer exists.", ephemeral=True)
            return
        if row["created_by"] != interaction.user.id and not can_manage(interaction):
            await interaction.response.send_message("You can only edit your own timers.", ephemeral=True)
            return
        await interaction.response.send_modal(TimerModal(row["timer_type"], edit_row=row))


class EditTimerView(discord.ui.View):
    def __init__(self, rows):
        super().__init__(timeout=60)
        self.add_item(EditTimerSelect(rows))


class HelperButtons(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Add Build", style=discord.ButtonStyle.primary, custom_id="helper:add_build")
    async def add_build(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(TimerModal("build"))

    @discord.ui.button(label="Add Research", style=discord.ButtonStyle.primary, custom_id="helper:add_research")
    async def add_research(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(TimerModal("research"))

    @discord.ui.button(label="Edit My Timer", style=discord.ButtonStyle.secondary, custom_id="helper:edit_timer")
    async def edit_timer(self, interaction: discord.Interaction, button: discord.ui.Button):
        with connect() as db:
            if can_manage(interaction):
                rows = db.execute(
                    """SELECT * FROM timers WHERE guild_id=? AND completed=0 AND end_ts>?
                       ORDER BY end_ts DESC LIMIT 25""",
                    (interaction.guild_id, int(datetime.now(timezone.utc).timestamp())),
                ).fetchall()
            else:
                rows = db.execute(
                    """SELECT * FROM timers WHERE guild_id=? AND created_by=? AND completed=0 AND end_ts>?
                       ORDER BY end_ts DESC LIMIT 25""",
                    (interaction.guild_id, interaction.user.id, int(datetime.now(timezone.utc).timestamp())),
                ).fetchall()
        if not rows:
            await interaction.response.send_message("You don't have any active timers to edit.", ephemeral=True)
            return
        await interaction.response.send_message(
            "Pick the timer you want to edit:", view=EditTimerView(rows), ephemeral=True
        )


class HelperBot(commands.Bot):
    async def setup_hook(self):
        init_db()
        self.add_view(HelperButtons())
        if GUILD_ID:
            guild = discord.Object(id=int(GUILD_ID))
            self.tree.copy_global_to(guild=guild)
            await self.tree.sync(guild=guild)
            print(f"Commands synced to guild {GUILD_ID}")
        else:
            await self.tree.sync()
            print("Global commands synced")


bot = HelperBot(command_prefix="!", intents=intents)


async def refresh_board(guild_id: int):
    with connect() as db:
        board_row = db.execute("SELECT * FROM boards WHERE guild_id=?", (guild_id,)).fetchone()
    if not board_row:
        return

    channel = bot.get_channel(board_row["channel_id"])
    if channel is None:
        try:
            channel = await bot.fetch_channel(board_row["channel_id"])
        except discord.DiscordException:
            return

    try:
        msg = await channel.fetch_message(board_row["message_id"])
        await msg.edit(embed=make_board_embed(guild_id), view=HelperButtons())
    except discord.NotFound:
        with connect() as db:
            db.execute("DELETE FROM boards WHERE guild_id=?", (guild_id,))
    except discord.DiscordException:
        pass


def can_manage(interaction: discord.Interaction) -> bool:
    return bool(
        interaction.guild
        and isinstance(interaction.user, discord.Member)
        and (interaction.user.guild_permissions.manage_guild or interaction.user.guild_permissions.administrator)
    )


def add_timer(guild_id, player, timer_type, project, days, hours, minutes, created_by):
    now = datetime.now(timezone.utc)
    end = now + timedelta(days=days, hours=hours, minutes=minutes)
    with connect() as db:
        cur = db.execute("""
            INSERT INTO timers(guild_id, player, timer_type, project, end_ts, created_by, created_ts)
            VALUES(?,?,?,?,?,?,?)
        """, (
            guild_id, player.strip(), timer_type, project.strip(),
            int(end.timestamp()), created_by, int(now.timestamp())
        ))
        return cur.lastrowid, int(end.timestamp())


@app_commands.guild_only()
@bot.tree.command(name="addbuild", description="Add a construction timer.")
@app_commands.describe(player="Player name", days="Days remaining", project="What is being built",
                       hours="Extra hours", minutes="Extra minutes")
async def addbuild(
    interaction: discord.Interaction,
    player: str,
    days: app_commands.Range[int, 0, 3650],
    project: str = "Power Plant",
    hours: app_commands.Range[int, 0, 23] = 0,
    minutes: app_commands.Range[int, 0, 59] = 0,
):
    timer_id, end_ts = add_timer(
        interaction.guild_id, player, "build", project, days, hours, minutes, interaction.user.id
    )
    await interaction.response.send_message(
        f"Added **#{timer_id} {player}** — {project} — ends <t:{end_ts}:R>.", ephemeral=True
    )
    await refresh_board(interaction.guild_id)


@app_commands.guild_only()
@bot.tree.command(name="addresearch", description="Add a research timer.")
@app_commands.describe(player="Player name", days="Days remaining", project="Research name",
                       hours="Extra hours", minutes="Extra minutes")
async def addresearch(
    interaction: discord.Interaction,
    player: str,
    days: app_commands.Range[int, 0, 3650],
    project: str = "Research",
    hours: app_commands.Range[int, 0, 23] = 0,
    minutes: app_commands.Range[int, 0, 59] = 0,
):
    timer_id, end_ts = add_timer(
        interaction.guild_id, player, "research", project, days, hours, minutes, interaction.user.id
    )
    await interaction.response.send_message(
        f"Added **#{timer_id} {player}** — {project} — ends <t:{end_ts}:R>.", ephemeral=True
    )
    await refresh_board(interaction.guild_id)


@app_commands.guild_only()
@bot.tree.command(name="helpers", description="Show the current helper priority list.")
async def helpers(interaction: discord.Interaction):
    await interaction.response.send_message(embed=make_board_embed(interaction.guild_id))


@app_commands.guild_only()
@bot.tree.command(name="timers", description="Show all active timers, including below-threshold timers.")
async def timers(interaction: discord.Interaction):
    rows = all_active_rows(interaction.guild_id)
    if not rows:
        await interaction.response.send_message("No active timers.", ephemeral=True)
        return
    text = "\n".join(
        f"**#{r['id']}** {r['player']} · {r['timer_type'].title()} · "
        f"{r['project']} · {human_remaining(r['end_ts'])} · <t:{r['end_ts']}:R>"
        for r in rows
    )
    await interaction.response.send_message(text[:1900], ephemeral=True)


@app_commands.guild_only()
@bot.tree.command(name="updatetime", description="Update the remaining time on one of your timers.")
@app_commands.describe(
    timer_id="The # number shown on the helper board",
    days="New days remaining",
    hours="New extra hours remaining",
    minutes="New extra minutes remaining",
)
async def updatetime(
    interaction: discord.Interaction,
    timer_id: int,
    days: app_commands.Range[int, 0, 3650],
    hours: app_commands.Range[int, 0, 23] = 0,
    minutes: app_commands.Range[int, 0, 59] = 0,
):
    with connect() as db:
        row = db.execute(
            "SELECT * FROM timers WHERE id=? AND guild_id=?",
            (timer_id, interaction.guild_id),
        ).fetchone()

        if not row:
            await interaction.response.send_message(
                "I couldn't find that timer.", ephemeral=True
            )
            return

        if row["created_by"] != interaction.user.id and not can_manage(interaction):
            await interaction.response.send_message(
                "You can only update timers you added yourself. Server managers can update any timer.",
                ephemeral=True,
            )
            return

        new_end = datetime.now(timezone.utc) + timedelta(
            days=days, hours=hours, minutes=minutes
        )
        new_end_ts = int(new_end.timestamp())
        db.execute(
            "UPDATE timers SET end_ts=?, completed=0 WHERE id=?",
            (new_end_ts, timer_id),
        )

    await interaction.response.send_message(
        f"Updated **#{timer_id} {row['player']}** to "
        f"**{days}d {hours}h {minutes}m remaining** · ends <t:{new_end_ts}:R>.",
        ephemeral=True,
    )
    await refresh_board(interaction.guild_id)


@app_commands.guild_only()
@bot.tree.command(name="editimer", description="Edit the player name, project, type, or remaining time on a timer.")
@app_commands.describe(
    timer_id="The # number shown on the helper board",
    player="New player name (leave blank to keep current)",
    project="New build/research description (leave blank to keep current)",
    timer_type="Change timer type",
    days="Replace the timer with this many days remaining",
    hours="Extra hours when replacing remaining time",
    minutes="Extra minutes when replacing remaining time",
)
@app_commands.choices(timer_type=[
    app_commands.Choice(name="Build", value="build"),
    app_commands.Choice(name="Research", value="research"),
])
async def editimer(
    interaction: discord.Interaction,
    timer_id: int,
    player: str | None = None,
    project: str | None = None,
    timer_type: app_commands.Choice[str] | None = None,
    days: app_commands.Range[int, 0, 3650] | None = None,
    hours: app_commands.Range[int, 0, 23] = 0,
    minutes: app_commands.Range[int, 0, 59] = 0,
):
    with connect() as db:
        row = db.execute(
            "SELECT * FROM timers WHERE id=? AND guild_id=?",
            (timer_id, interaction.guild_id),
        ).fetchone()

        if not row:
            await interaction.response.send_message(
                "I couldn't find that timer.", ephemeral=True
            )
            return

        if row["created_by"] != interaction.user.id and not can_manage(interaction):
            await interaction.response.send_message(
                "You can only edit timers you added yourself. Server managers can edit any timer.",
                ephemeral=True,
            )
            return

        new_player = player.strip() if player else row["player"]
        new_project = project.strip() if project else row["project"]
        new_type = timer_type.value if timer_type else row["timer_type"]
        new_end_ts = row["end_ts"]

        if days is not None:
            new_end = datetime.now(timezone.utc) + timedelta(
                days=days, hours=hours, minutes=minutes
            )
            new_end_ts = int(new_end.timestamp())

        db.execute(
            """
            UPDATE timers
            SET player=?, project=?, timer_type=?, end_ts=?, completed=0
            WHERE id=?
            """,
            (new_player, new_project, new_type, new_end_ts, timer_id),
        )

    await interaction.response.send_message(
        f"Updated **#{timer_id}** → **{new_player}** · "
        f"{new_type.title()} · {new_project} · ends <t:{new_end_ts}:R>.",
        ephemeral=True,
    )
    await refresh_board(interaction.guild_id)


@app_commands.guild_only()
@bot.tree.command(name="done", description="Mark a timer complete.")
@app_commands.describe(timer_id="The # number shown on the helper board")
async def done(interaction: discord.Interaction, timer_id: int):
    with connect() as db:
        row = db.execute(
            "SELECT * FROM timers WHERE id=? AND guild_id=?", (timer_id, interaction.guild_id)
        ).fetchone()
        if not row:
            await interaction.response.send_message("I couldn't find that timer.", ephemeral=True)
            return
        if row["created_by"] != interaction.user.id and not can_manage(interaction):
            await interaction.response.send_message(
                "Only the person who added it or a server manager can mark it done.", ephemeral=True
            )
            return
        db.execute("UPDATE timers SET completed=1 WHERE id=?", (timer_id,))
    await interaction.response.send_message(f"Timer **#{timer_id}** marked complete.", ephemeral=True)
    await refresh_board(interaction.guild_id)


@app_commands.guild_only()
@bot.tree.command(name="remove", description="Delete a timer.")
@app_commands.describe(timer_id="The # number shown on the helper board")
async def remove(interaction: discord.Interaction, timer_id: int):
    with connect() as db:
        row = db.execute(
            "SELECT * FROM timers WHERE id=? AND guild_id=?", (timer_id, interaction.guild_id)
        ).fetchone()
        if not row:
            await interaction.response.send_message("I couldn't find that timer.", ephemeral=True)
            return
        if row["created_by"] != interaction.user.id and not can_manage(interaction):
            await interaction.response.send_message(
                "Only the person who added it or a server manager can remove it.", ephemeral=True
            )
            return
        db.execute("DELETE FROM timers WHERE id=?", (timer_id,))
    await interaction.response.send_message(f"Timer **#{timer_id}** removed.", ephemeral=True)
    await refresh_board(interaction.guild_id)


@app_commands.guild_only()
@bot.tree.command(name="board", description="Create/move the auto-updating helper board to this channel.")
@app_commands.checks.has_permissions(manage_guild=True)
async def board(interaction: discord.Interaction):
    await interaction.response.defer(ephemeral=True)
    message = await interaction.channel.send(embed=make_board_embed(interaction.guild_id), view=HelperButtons())
    with connect() as db:
        db.execute("""
            INSERT INTO boards(guild_id, channel_id, message_id)
            VALUES(?,?,?)
            ON CONFLICT(guild_id)
            DO UPDATE SET channel_id=excluded.channel_id, message_id=excluded.message_id
        """, (interaction.guild_id, interaction.channel_id, message.id))
    await interaction.followup.send("Auto-updating helper board created in this channel.", ephemeral=True)


@app_commands.guild_only()
@bot.tree.command(name="seedcurrent", description="Load the supplied 9/10 build/research list.")
@app_commands.checks.has_permissions(manage_guild=True)
async def seedcurrent(interaction: discord.Interaction):
    with connect() as db:
        count = db.execute(
            "SELECT COUNT(*) AS c FROM timers WHERE guild_id=?", (interaction.guild_id,)
        ).fetchone()["c"]
        if count:
            await interaction.response.send_message(
                "This server already has timers, so I didn't seed the list and create duplicates.",
                ephemeral=True,
            )
            return

        # Snapshot basis: 2026-09-10 10:41 AM America/Los_Angeles = 17:41 UTC.
        seed_start = datetime(2026, 9, 10, 17, 41, tzinfo=timezone.utc)
        entries = [
            ("B3ndm3ov3r", "build", "Power Plant", 11),
            ("Tomcat", "build", "Power Plant", 24),
            ("GabrielValeriote", "build", "Power Plant", 14),
            ("Kickflip", "build", "Power Plant", 19),
            ("Advent", "build", "Power Plant", 18),
            ("Winry", "build", "Construction", 22),
            ("Winry", "research", "Research Timer 1", 55),
            ("Winry", "research", "Research Timer 2", 19),
        ]
        created_ts = int(datetime.now(timezone.utc).timestamp())
        for player, timer_type, project, days in entries:
            end_ts = int((seed_start + timedelta(days=days)).timestamp())
            db.execute("""
                INSERT INTO timers(guild_id, player, timer_type, project, end_ts, created_by, created_ts)
                VALUES(?,?,?,?,?,?,?)
            """, (
                interaction.guild_id, player, timer_type, project,
                end_ts, interaction.user.id, created_ts
            ))

    await interaction.response.send_message("Loaded the 9/10 helper list.", ephemeral=True)
    await refresh_board(interaction.guild_id)


@board.error
@seedcurrent.error
async def admin_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
    if isinstance(error, app_commands.MissingPermissions):
        msg = "You need **Manage Server** permission for that command."
        if interaction.response.is_done():
            await interaction.followup.send(msg, ephemeral=True)
        else:
            await interaction.response.send_message(msg, ephemeral=True)
    else:
        raise error


@tasks.loop(minutes=REFRESH_MINUTES)
async def auto_refresh():
    with connect() as db:
        guild_ids = [r["guild_id"] for r in db.execute("SELECT guild_id FROM boards").fetchall()]
    for guild_id in guild_ids:
        await refresh_board(guild_id)
        await asyncio.sleep(1)


@auto_refresh.before_loop
async def before_auto_refresh():
    await bot.wait_until_ready()


@bot.event
async def on_ready():
    print(f"Logged in as {bot.user} (ID: {bot.user.id})")
    if not auto_refresh.is_running():
        auto_refresh.start()


if __name__ == "__main__":
    if not TOKEN:
        raise RuntimeError("DISCORD_TOKEN is missing. Copy .env.example to .env and paste your bot token.")
    bot.run(TOKEN)
