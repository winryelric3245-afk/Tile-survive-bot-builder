import os
import sqlite3
import asyncio
import json
import math
import logging
from datetime import datetime, timedelta, timezone

import discord
from discord import app_commands
from discord.ext import commands, tasks
from dotenv import load_dotenv

load_dotenv()

TOKEN = os.getenv("DISCORD_TOKEN")
GUILD_ID = os.getenv("GUILD_ID")
DB_PATH = os.getenv("DB_PATH", "helper_bot.db")
BUILD_THRESHOLD_DAYS = float(os.getenv("BUILD_THRESHOLD_DAYS", "10"))
RESEARCH_THRESHOLD_DAYS = float(os.getenv("RESEARCH_THRESHOLD_DAYS", "7"))
REFRESH_MINUTES = int(os.getenv("REFRESH_MINUTES", "10"))

intents = discord.Intents.default()

PRIORITIES = {
    4: ("URGENT", "🔴"),
    3: ("HIGH", "🟠"),
    2: ("NORMAL", "🟡"),
    1: ("LOW", "🟢"),
}


def connect():
    db = sqlite3.connect(DB_PATH, timeout=20)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA busy_timeout=20000")
    return db


def init_db():
    with connect() as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS timers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id INTEGER NOT NULL,
                player TEXT NOT NULL,
                timer_type TEXT NOT NULL CHECK(timer_type IN ('build','research')),
                project TEXT NOT NULL,
                end_ts INTEGER NOT NULL,
                created_by INTEGER,
                created_ts INTEGER NOT NULL,
                completed INTEGER NOT NULL DEFAULT 0,
                priority INTEGER NOT NULL DEFAULT 2
            )
        """)
        cols = {r["name"] for r in db.execute("PRAGMA table_info(timers)").fetchall()}
        if "priority" not in cols:
            db.execute("ALTER TABLE timers ADD COLUMN priority INTEGER NOT NULL DEFAULT 2")
        for name, ddl in {
            "original_seconds": "INTEGER NOT NULL DEFAULT 0",
            "last_update_ts": "INTEGER NOT NULL DEFAULT 0",
            "skill_count": "INTEGER NOT NULL DEFAULT 0",
            "last_skill_ts": "INTEGER NOT NULL DEFAULT 0",
            "priority_override": "INTEGER NOT NULL DEFAULT 0",
            "owner_id": "INTEGER NOT NULL DEFAULT 0",
        }.items():
            if name not in cols:
                db.execute(f"ALTER TABLE timers ADD COLUMN {name} {ddl}")
        db.execute("UPDATE timers SET original_seconds=MAX(0,end_ts-created_ts) WHERE original_seconds=0")
        db.execute("UPDATE timers SET last_update_ts=created_ts WHERE last_update_ts=0")
        db.execute("UPDATE timers SET owner_id=created_by WHERE owner_id=0 AND created_by IS NOT NULL")
        db.execute("""CREATE TABLE IF NOT EXISTS timer_submissions (
            timer_id INTEGER PRIMARY KEY, guild_id INTEGER NOT NULL,
            player_key TEXT NOT NULL, timer_type TEXT NOT NULL,
            submitted_ts INTEGER NOT NULL
        )""")
        # Backfill only known timers. Historical deleted submissions are unrecoverable.
        db.execute("""INSERT OR IGNORE INTO timer_submissions(timer_id,guild_id,player_key,timer_type,submitted_ts)
            SELECT id,guild_id,lower(trim(player)),timer_type,created_ts FROM timers""")
        db.execute("""CREATE TRIGGER IF NOT EXISTS record_timer_submission AFTER INSERT ON timers
            BEGIN INSERT OR IGNORE INTO timer_submissions(timer_id,guild_id,player_key,timer_type,submitted_ts)
            VALUES(NEW.id,NEW.guild_id,lower(trim(NEW.player)),NEW.timer_type,NEW.created_ts); END""")
        db.execute("""CREATE INDEX IF NOT EXISTS idx_timer_submission_week
            ON timer_submissions(guild_id,player_key,timer_type,submitted_ts)""")
        db.execute("""CREATE TABLE IF NOT EXISTS skill_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id INTEGER NOT NULL,
            actor_id INTEGER NOT NULL, timer_type TEXT NOT NULL, player TEXT NOT NULL,
            event_ts INTEGER NOT NULL, before_json TEXT NOT NULL, undone INTEGER NOT NULL DEFAULT 0, percent INTEGER NOT NULL DEFAULT 15
        )""")
        skill_cols = {r["name"] for r in db.execute("PRAGMA table_info(skill_events)")}
        if "percent" not in skill_cols:
            db.execute("ALTER TABLE skill_events ADD COLUMN percent INTEGER NOT NULL DEFAULT 15")
        db.execute("""CREATE TABLE IF NOT EXISTS reminder_settings (
            guild_id INTEGER PRIMARY KEY, channel_id INTEGER NOT NULL,
            role_id INTEGER, enabled INTEGER NOT NULL DEFAULT 1,
            last_sent_day TEXT
        )""")
        db.execute("""
            CREATE TABLE IF NOT EXISTS boards (
                guild_id INTEGER PRIMARY KEY,
                channel_id INTEGER NOT NULL,
                message_id INTEGER NOT NULL
            )
        """)


def human_remaining(end_ts: int) -> str:
    seconds = max(0, end_ts - int(datetime.now(timezone.utc).timestamp()))
    days, rem = divmod(seconds, 86400)
    hours, rem = divmod(rem, 3600)
    minutes = rem // 60
    if days:
        return f"{days}d {hours}h"
    if hours:
        return f"{hours}h {minutes}m"
    return f"{minutes}m"


def priority_text(value: int) -> str:
    """Compact display; keep numeric scoring internal for ordering."""
    score = int(value)
    if score >= 40:
        return "🔴 Urgent"
    if score >= 30:
        return "🟠 High"
    if score >= 20:
        return "🟡 Normal"
    return "🟢 Low"


def compact_timer_line(row, show_category=False):
    """Single line that preserves submission date and waiting days."""
    now = int(datetime.now(timezone.utc).timestamp())
    waiting = max(0, (now - max(row["created_ts"], row["last_skill_ts"] or 0)) // 86400)
    submitted = datetime.fromtimestamp(row["created_ts"], timezone.utc).strftime("%m/%d")
    category = f"{row['timer_type'].title()}: " if show_category else ""
    emoji = priority_text(calculated_priority(row, now)).split(" ", 1)[0]
    return (f"{emoji} {category}{human_remaining(row['end_ts'])} | "
            f"{row['player']} | {submitted} | Wait: {waiting}d "
            f"| Skills: {row['skill_count']}")


def validate_timer(player, project, days, hours=0, minutes=0):
    if not player or not player.strip() or not project or not project.strip():
        raise ValueError("Player and project names cannot be blank.")
    if not (0 <= days <= 3650 and 0 <= hours <= 23 and 0 <= minutes <= 59):
        raise ValueError("Enter valid days, hours and minutes.")
    if days == hours == minutes == 0:
        raise ValueError("Timer must be longer than zero.")


def weekly_submission_count(row, now):
    dt = datetime.fromtimestamp(now, timezone.utc)
    monday = (dt - timedelta(days=dt.weekday())).replace(hour=0, minute=0, second=0, microsecond=0)
    with connect() as db:
        result = db.execute("""SELECT COUNT(*) AS n FROM timer_submissions
            WHERE guild_id=? AND player_key=? AND timer_type=?
            AND submitted_ts>=? AND submitted_ts<=?""",
            (row["guild_id"], row["player"].strip().lower(), row["timer_type"],
             int(monday.timestamp()), now)).fetchone()
        return result["n"]


def calculated_priority(row, now=None):
    now = int(now if now is not None else datetime.now(timezone.utc).timestamp())
    if row["priority_override"]:
        return int(row["priority"])
    original_days = row["original_seconds"] / 86400
    waiting_days = max(0, (now - max(row["created_ts"], row["last_skill_ts"] or 0)) // 86400)
    base = 20 if original_days >= 28 else 15 if original_days >= 21 else 10 if original_days >= 14 else 5
    # Penalize only the individual submission, not older timers from the same player.
    dt = datetime.fromtimestamp(row["created_ts"], timezone.utc)
    monday = (dt - timedelta(days=dt.weekday())).replace(hour=0, minute=0, second=0, microsecond=0)
    with connect() as db:
        ordinal = db.execute("""SELECT COUNT(*) n FROM timer_submissions
            WHERE guild_id=? AND player_key=? AND timer_type=? AND submitted_ts>=?
            AND (submitted_ts<? OR (submitted_ts=? AND timer_id<=?))""",
            (row["guild_id"], row["player"].strip().lower(), row["timer_type"],
             int(monday.timestamp()), row["created_ts"], row["created_ts"], row["id"])).fetchone()["n"]
    return max(0, base + 3 * waiting_days - 5 * max(0, ordinal - 2))


def sorted_fair(rows):
    now = int(datetime.now(timezone.utc).timestamp())
    return sorted(rows, key=lambda r: (-calculated_priority(r, now), r["skill_count"], r["last_skill_ts"], -r["original_seconds"], r["created_ts"]))


def timer_details(row):
    now = int(datetime.now(timezone.utc).timestamp())
    waiting = max(0, (now - max(row["created_ts"], row["last_skill_ts"] or 0)) // 86400)
    stale = " · ⚠️ Review" if now - row["last_update_ts"] >= 7 * 86400 else ""
    submissions = weekly_submission_count(row, now)
    return f"Added <t:{row['created_ts']}:d> · Waiting {waiting}d · Skills {row['skill_count']} · Weekly submissions {submissions}{stale}"


def apply_skill(guild_id, actor_id, timer_type, player, percent=15, timer_id=None):
    if percent not in (5, 10, 15):
        raise ValueError("Skill percent must be 5, 10, or 15")
    now = int(datetime.now(timezone.utc).timestamp())
    with connect() as db:
        rows = db.execute("""SELECT * FROM timers WHERE guild_id=? AND timer_type=?
            AND player=? COLLATE NOCASE AND completed=0 AND end_ts>?""", (guild_id,timer_type,player,now)).fetchall()
        if timer_id is not None:
            rows = [r for r in rows if r["id"] == timer_id]
        if not rows: return None, 0
        before = []
        for r in rows:
            before.append([r["id"],r["end_ts"],r["skill_count"],r["last_skill_ts"],r["last_update_ts"]])
            remaining = r["end_ts"] - now
            new_end = now + max(0, remaining - math.ceil(remaining * percent / 100))
            db.execute("UPDATE timers SET end_ts=?, skill_count=skill_count+1, last_skill_ts=?,last_update_ts=? WHERE id=?",(new_end,now,now,r["id"]))
        cur=db.execute("INSERT INTO skill_events(guild_id,actor_id,timer_type,player,event_ts,before_json,percent) VALUES(?,?,?,?,?,?,?)",
            (guild_id,actor_id,timer_type,player,now,json.dumps(before),percent))
        return cur.lastrowid, len(rows)


def qualifying_rows(guild_id: int):
    now = int(datetime.now(timezone.utc).timestamp())
    build_cutoff = now + int(BUILD_THRESHOLD_DAYS * 86400)
    research_cutoff = now + int(RESEARCH_THRESHOLD_DAYS * 86400)
    with connect() as db:
        builds = db.execute("""
            SELECT * FROM timers
            WHERE guild_id=? AND completed=0 AND timer_type='build' AND end_ts > ?
            ORDER BY priority DESC, end_ts DESC
        """, (guild_id, build_cutoff)).fetchall()
        research = db.execute("""
            SELECT * FROM timers
            WHERE guild_id=? AND completed=0 AND timer_type='research' AND end_ts > ?
            ORDER BY priority DESC, end_ts DESC
        """, (guild_id, research_cutoff)).fetchall()
    return sorted_fair(builds), sorted_fair(research)


def all_active_rows(guild_id: int):
    now = int(datetime.now(timezone.utc).timestamp())
    with connect() as db:
        return db.execute("""
            SELECT * FROM timers
            WHERE guild_id=? AND completed=0 AND end_ts > ?
            ORDER BY priority DESC, timer_type, end_ts DESC
        """, (guild_id, now)).fetchall()


def make_board_embed(guild_id: int) -> discord.Embed:
    active = all_active_rows(guild_id)
    # Hide timers with less than seven full days remaining from the public board only.
    # Keep them available in /timers and management controls.
    cutoff = int(datetime.now(timezone.utc).timestamp()) + 7 * 86400
    visible = [r for r in active if r["end_ts"] >= cutoff]
    builds = sorted_fair([r for r in visible if r["timer_type"] == "build"])
    research = sorted_fair([r for r in visible if r["timer_type"] == "research"])
    embed = discord.Embed(
        title="Bob the Builder — Priority Board",
        description="7d+ remaining · time left · player · submitted (MM/DD UTC) · waiting · skills. /timers shows all.",
        timestamp=datetime.now(timezone.utc),
    )

    def preview(rows):
        if not rows:
            return "No active timers."
        output = []
        length = 0
        for row in rows:
            line = compact_timer_line(row)
            # Discord embed field value hard limit: 1024 characters.
            # Reserve room for the overflow indicator.
            if length + len(line) + 1 > 910:
                break
            output.append(line)
            length += len(line) + 1
        hidden = len(rows) - len(output)
        if hidden:
            output.append(f"+{hidden} more — /timers")
        return "\n".join(output)

    embed.add_field(name=f"Construction ({len(builds)})", value=preview(builds), inline=False)
    embed.add_field(name=f"Research ({len(research)})", value=preview(research), inline=False)
    embed.set_footer(text=f"Showing 7d+: {len(builds)} Build / {len(research)} Research · All active: {len(active)} · Refresh {REFRESH_MINUTES} min")
    return embed


def can_manage(interaction: discord.Interaction) -> bool:
    return bool(
        interaction.guild
        and isinstance(interaction.user, discord.Member)
        and (interaction.user.guild_permissions.manage_guild or interaction.user.guild_permissions.administrator)
    )


def row_accessible(interaction: discord.Interaction, row) -> bool:
    return bool(row and (row["owner_id"] == interaction.user.id or row["created_by"] == interaction.user.id or can_manage(interaction)))


async def refresh_board(guild_id: int):
    with connect() as db:
        board_row = db.execute("SELECT * FROM boards WHERE guild_id=?", (guild_id,)).fetchone()
    if not board_row:
        return
    channel = bot.get_channel(board_row["channel_id"])
    if channel is None:
        try:
            channel = await bot.fetch_channel(board_row["channel_id"])
        except discord.DiscordException:
            return
    try:
        msg = await channel.fetch_message(board_row["message_id"])
        await msg.edit(embed=make_board_embed(guild_id), view=HelperButtons())
    except discord.NotFound:
        with connect() as db:
            db.execute("DELETE FROM boards WHERE guild_id=?", (guild_id,))
    except discord.DiscordException:
        pass


class TimerModal(discord.ui.Modal):
    def __init__(self, timer_type: str, edit_row=None):
        self.timer_type = timer_type
        self.edit_row = edit_row
        super().__init__(title=(f"Edit {timer_type.title()} Timer" if edit_row else f"Add {timer_type.title()} Timer"))
        now_ts = int(datetime.now(timezone.utc).timestamp())
        remain = max(0, edit_row["end_ts"] - now_ts) if edit_row else 0
        days_default = str(remain // 86400) if edit_row else ""
        hours_default = str((remain % 86400) // 3600) if edit_row else "0"
        self.player = discord.ui.TextInput(label="Player name", default=edit_row["player"] if edit_row else "", max_length=50)
        self.project = discord.ui.TextInput(
            label="Build / Research",
            default=edit_row["project"] if edit_row else ("Power Plant" if timer_type == "build" else "Research"),
            max_length=80,
        )
        self.days = discord.ui.TextInput(label="Days remaining", placeholder="Example: 24", default=days_default, max_length=4)
        self.hours = discord.ui.TextInput(label="Hours remaining (0-23)", placeholder="0", default=hours_default, required=False, max_length=2)
        self.add_item(self.player); self.add_item(self.project); self.add_item(self.days); self.add_item(self.hours)

    async def on_submit(self, interaction: discord.Interaction):
        try:
            days = int(self.days.value or 0); hours = int(self.hours.value or 0)
            if days < 0 or hours < 0 or hours > 23: raise ValueError
        except ValueError:
            await interaction.response.send_message("Enter valid days and hours (hours must be 0–23).", ephemeral=True)
            return
        try:
            validate_timer(self.player.value, self.project.value, days, hours)
        except ValueError as exc:
            await interaction.response.send_message(str(exc), ephemeral=True)
            return
        await interaction.response.defer(ephemeral=True, thinking=True)
        try:
            await self.save_timer(interaction, days, hours)
        except Exception:
            logging.exception("Failed to save timer via modal")
            await interaction.followup.send("Could not save timer. Check Bob's server log; no confirmation was recorded.", ephemeral=True)

    async def save_timer(self, interaction, days, hours):
        now = datetime.now(timezone.utc)
        end_ts = int((now + timedelta(days=days, hours=hours)).timestamp())
        if self.edit_row:
            with connect() as db:
                row = db.execute("SELECT * FROM timers WHERE id=? AND guild_id=?", (self.edit_row["id"], interaction.guild_id)).fetchone()
                if not row or not row_accessible(interaction, row):
                    raise ValueError("You cannot edit this timer.")
                db.execute("UPDATE timers SET player=?, project=?, timer_type=?, end_ts=?, completed=0,last_update_ts=?,original_seconds=? WHERE id=? AND guild_id=?",
                           (self.player.value.strip(), self.project.value.strip(), self.timer_type, end_ts, int(now.timestamp()),
                            max(0,end_ts-int(now.timestamp())),self.edit_row["id"],interaction.guild_id))
            msg = f"Updated **#{self.edit_row['id']} {self.player.value}** to **{days}d {hours}h** remaining."
        else:
            with connect() as db:
                cur = db.execute("""INSERT INTO timers(guild_id, player, timer_type, project, end_ts, created_by, created_ts, priority)
                                    VALUES(?,?,?,?,?,?,?,2)""",
                                 (interaction.guild_id, self.player.value.strip(), self.timer_type, self.project.value.strip(), end_ts,
                                  interaction.user.id, int(now.timestamp())))
                timer_id = cur.lastrowid
                db.execute("UPDATE timers SET original_seconds=?,last_update_ts=?,owner_id=? WHERE id=?",(max(0,end_ts-int(now.timestamp())),int(now.timestamp()),interaction.user.id,timer_id))
            msg = f"Added **#{timer_id} {self.player.value}** — **{days}d {hours}h** remaining · automatic priority."
        await interaction.followup.send(msg + " Check /timers to find it in the full list.", ephemeral=True)
        try:
            await refresh_board(interaction.guild_id)
        except Exception:
            logging.exception("Timer saved, but board refresh failed")


class TimerSelect(discord.ui.Select):
    def __init__(self, rows):
        options = [discord.SelectOption(
            label=f"#{r['id']} {r['player']}"[:100],
            description=f"{priority_text(calculated_priority(r))} · {r['timer_type'].title()} · {human_remaining(r['end_ts'])}"[:100],
            value=str(r["id"]),
        ) for r in rows[:25]]
        super().__init__(placeholder="Choose a timer to manage…", options=options)

    async def callback(self, interaction: discord.Interaction):
        timer_id = int(self.values[0])
        with connect() as db:
            row = db.execute("SELECT * FROM timers WHERE id=? AND guild_id=?", (timer_id, interaction.guild_id)).fetchone()
        if not row:
            await interaction.response.send_message("That timer no longer exists.", ephemeral=True); return
        if not row_accessible(interaction, row):
            await interaction.response.send_message("You can only manage your own timers.", ephemeral=True); return
        await interaction.response.edit_message(
            content=f"Managing **#{row['id']} {row['player']}** · {priority_text(row['priority'])} · {row['project']} · {human_remaining(row['end_ts'])}",
            view=TimerActionsView(row),
        )


class TimerPickerView(discord.ui.View):
    def __init__(self, rows, page=0):
        super().__init__(timeout=180)
        self.rows = rows
        self.page = max(0, min(page, (len(rows)-1)//25))
        self.render()

    def render(self):
        self.clear_items()
        self.add_item(TimerSelect(self.rows[self.page*25:(self.page+1)*25]))
        if len(self.rows) > 25:
            prev = discord.ui.Button(label="Previous", style=discord.ButtonStyle.secondary, disabled=self.page == 0)
            nxt = discord.ui.Button(label="Next", style=discord.ButtonStyle.secondary, disabled=(self.page+1)*25 >= len(self.rows))
            async def go(interaction, delta):
                self.page += delta
                self.render()
                await interaction.response.edit_message(content=f"Manage timers — page {self.page+1}/{(len(self.rows)+24)//25}", view=self)
            async def previous(interaction): await go(interaction, -1)
            async def next_page(interaction): await go(interaction, 1)
            prev.callback = previous
            nxt.callback = next_page
            self.add_item(prev)
            self.add_item(nxt)


class PrioritySelect(discord.ui.Select):
    def __init__(self, timer_id: int):
        self.timer_id = timer_id
        options = [
            discord.SelectOption(label="URGENT", description="Top of the helper list", value="40", emoji="🔴"),
            discord.SelectOption(label="HIGH", description="Above normal priority", value="30", emoji="🟠"),
            discord.SelectOption(label="NORMAL", description="Default priority", value="20", emoji="🟡"),
            discord.SelectOption(label="LOW", description="Lowest priority", value="10", emoji="🟢"),
        ]
        super().__init__(placeholder="Set priority…", options=options)

    async def callback(self, interaction: discord.Interaction):
        with connect() as db:
            row = db.execute("SELECT * FROM timers WHERE id=? AND guild_id=?", (self.timer_id, interaction.guild_id)).fetchone()
            if not row_accessible(interaction, row):
                await interaction.response.send_message("You can't change that timer.", ephemeral=True); return
            p = int(self.values[0])
            if not can_manage(interaction):
                await interaction.response.send_message("Only managers can override automatic priority.", ephemeral=True); return
            db.execute("UPDATE timers SET priority=?, priority_override=1 WHERE id=?", (p, self.timer_id))
        await interaction.response.edit_message(content=f"Priority for **#{self.timer_id} {row['player']}** set to {priority_text(p)}.", view=None)
        await refresh_board(interaction.guild_id)


class PriorityView(discord.ui.View):
    def __init__(self, timer_id: int):
        super().__init__(timeout=60)
        self.add_item(PrioritySelect(timer_id))


class ConfirmDeleteView(discord.ui.View):
    def __init__(self, timer_id: int):
        super().__init__(timeout=45)
        self.timer_id = timer_id

    @discord.ui.button(label="Yes, Delete", style=discord.ButtonStyle.danger)
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
        with connect() as db:
            row = db.execute("SELECT * FROM timers WHERE id=? AND guild_id=?", (self.timer_id, interaction.guild_id)).fetchone()
            if not row_accessible(interaction, row):
                await interaction.response.send_message("You can't delete that timer.", ephemeral=True); return
            db.execute("DELETE FROM timers WHERE id=?", (self.timer_id,))
        await interaction.response.edit_message(content=f"Deleted timer **#{self.timer_id}**.", view=None)
        await refresh_board(interaction.guild_id)

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(content="Delete cancelled.", view=None)


class TimerActionsView(discord.ui.View):
    def __init__(self, row):
        super().__init__(timeout=90)
        self.timer_id = row["id"]
        self.timer_type = row["timer_type"]

    async def fetch_access(self, interaction):
        with connect() as db:
            row = db.execute("SELECT * FROM timers WHERE id=? AND guild_id=?", (self.timer_id, interaction.guild_id)).fetchone()
        return row if row_accessible(interaction, row) else None

    @discord.ui.button(label="Edit", style=discord.ButtonStyle.primary)
    async def edit(self, interaction: discord.Interaction, button: discord.ui.Button):
        row = await self.fetch_access(interaction)
        if not row: await interaction.response.send_message("That timer isn't available to you.", ephemeral=True); return
        await interaction.response.send_modal(TimerModal(row["timer_type"], edit_row=row))

    @discord.ui.button(label="Priority", style=discord.ButtonStyle.secondary)
    async def priority(self, interaction: discord.Interaction, button: discord.ui.Button):
        row = await self.fetch_access(interaction)
        if not row: await interaction.response.send_message("That timer isn't available to you.", ephemeral=True); return
        await interaction.response.edit_message(content=f"Set priority for **#{self.timer_id} {row['player']}**:", view=PriorityView(self.timer_id))

    @discord.ui.button(label="Done", style=discord.ButtonStyle.success)
    async def done(self, interaction: discord.Interaction, button: discord.ui.Button):
        row = await self.fetch_access(interaction)
        if not row: await interaction.response.send_message("That timer isn't available to you.", ephemeral=True); return
        with connect() as db: db.execute("UPDATE timers SET completed=1 WHERE id=?", (self.timer_id,))
        await interaction.response.edit_message(content=f"Marked **#{self.timer_id} {row['player']}** complete.", view=None)
        await refresh_board(interaction.guild_id)

    @discord.ui.button(label="Delete", style=discord.ButtonStyle.danger)
    async def delete(self, interaction: discord.Interaction, button: discord.ui.Button):
        row = await self.fetch_access(interaction)
        if not row: await interaction.response.send_message("That timer isn't available to you.", ephemeral=True); return
        await interaction.response.edit_message(content=f"Delete **#{self.timer_id} {row['player']}** permanently?", view=ConfirmDeleteView(self.timer_id))


class SkillPercentView(discord.ui.View):
    def __init__(self, timer_type, player):
        super().__init__(timeout=120)
        self.timer_type, self.player = timer_type, player

    async def apply(self, interaction, percent):
        if not can_manage(interaction):
            await interaction.response.send_message("Only managers can apply skills.", ephemeral=True)
            return
        event_id, count = apply_skill(interaction.guild_id, interaction.user.id,
                                      self.timer_type, self.player, percent)
        if not count:
            await interaction.response.edit_message(content="No active matching timers remain.", view=None)
            return
        await interaction.response.edit_message(
            content=f"Applied {percent}% {self.timer_type.title()} skill to **{count}** timer(s) for **{self.player}**. Event #{event_id}.", view=None)
        await refresh_board(interaction.guild_id)

    @discord.ui.button(label="5%", style=discord.ButtonStyle.primary)
    async def five(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.apply(interaction, 5)

    @discord.ui.button(label="10%", style=discord.ButtonStyle.primary)
    async def ten(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.apply(interaction, 10)

    @discord.ui.button(label="15%", style=discord.ButtonStyle.success)
    async def fifteen(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.apply(interaction, 15)


class SkillTargetSelect(discord.ui.Select):
    def __init__(self, timer_type, players):
        self.timer_type = timer_type
        super().__init__(placeholder=f"Choose {timer_type.title()} player…", min_values=1, max_values=1,
                         options=[discord.SelectOption(label=name[:100], value=str(i)) for i, name in enumerate(players)])
        self.players = players

    async def callback(self, interaction: discord.Interaction):
        if not can_manage(interaction):
            await interaction.response.send_message("Only managers can apply skills.", ephemeral=True)
            return
        player = self.players[int(self.values[0])]
        await interaction.response.edit_message(
            content=f"Choose skill reduction for **{player}** ({self.timer_type.title()}):",
            view=SkillPercentView(self.timer_type, player))


class SkillTargetView(discord.ui.View):
    def __init__(self, timer_type, players, page=0):
        super().__init__(timeout=180)
        self.timer_type, self.players, self.page = timer_type, players, page
        self.render()

    def render(self):
        self.clear_items()
        self.add_item(SkillTargetSelect(self.timer_type, self.players[self.page*25:(self.page+1)*25]))
        if len(self.players) > 25:
            prev = discord.ui.Button(label="Previous", style=discord.ButtonStyle.secondary, disabled=self.page == 0)
            nxt = discord.ui.Button(label="Next", style=discord.ButtonStyle.secondary, disabled=(self.page+1)*25 >= len(self.players))
            async def go(interaction, delta):
                self.page += delta
                self.render()
                await interaction.response.edit_message(content=f"**{self.timer_type.title()} only** — page {self.page+1}/{(len(self.players)+24)//25}", view=self)
            async def previous(interaction): await go(interaction, -1)
            async def next_page(interaction): await go(interaction, 1)
            prev.callback = previous
            nxt.callback = next_page
            self.add_item(prev)
            self.add_item(nxt)


class SkillTypeView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=120)

    async def choose(self, interaction, timer_type):
        now = int(datetime.now(timezone.utc).timestamp())
        with connect() as db:
            rows = db.execute("SELECT MIN(trim(player)) AS player FROM timers WHERE guild_id=? AND timer_type=? AND completed=0 AND end_ts>? GROUP BY lower(trim(player)) ORDER BY player COLLATE NOCASE", (interaction.guild_id, timer_type, now)).fetchall()
        players = [r["player"] for r in rows]
        if not players:
            await interaction.response.edit_message(content=f"No active {timer_type} timers.", view=None); return
        await interaction.response.edit_message(content=f"**{timer_type.title()} skills only** — select a player with an active {timer_type} timer:", view=SkillTargetView(timer_type, players))

    @discord.ui.button(label="Build", style=discord.ButtonStyle.primary)
    async def build(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.choose(interaction, "build")

    @discord.ui.button(label="Research", style=discord.ButtonStyle.primary)
    async def research(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.choose(interaction, "research")


class UndoSkillSelect(discord.ui.Select):
    def __init__(self, events):
        super().__init__(placeholder="Choose skill event to undo…", options=[discord.SelectOption(label=f"#{r['id']} {r['player']} ({r['timer_type']})"[:100], value=str(r['id'])) for r in events])

    async def callback(self, interaction: discord.Interaction):
        if not can_manage(interaction):
            await interaction.response.send_message("Only managers can undo skills.", ephemeral=True); return
        event_id = int(self.values[0])
        with connect() as db:
            ev = db.execute("SELECT * FROM skill_events WHERE id=? AND guild_id=? AND undone=0", (event_id, interaction.guild_id)).fetchone()
            if not ev:
                await interaction.response.edit_message(content="Event already undone or unavailable.", view=None); return
            before = json.loads(ev["before_json"])
            for entry in before:
                timer_id, old_end, old_count, old_skill = entry[:4]
                r = db.execute("SELECT * FROM timers WHERE id=? AND guild_id=?", (timer_id, interaction.guild_id)).fetchone()
                expected_end = ev["event_ts"] + max(0, old_end - ev["event_ts"] - math.ceil(max(0, old_end-ev["event_ts"]) * ev["percent"] / 100))
                if not r or r["last_skill_ts"] != ev["event_ts"] or r["skill_count"] != old_count+1 or r["end_ts"] != expected_end or (len(entry)>4 and r["last_update_ts"] != ev["event_ts"]):
                    await interaction.response.edit_message(content="Cannot safely undo: a timer was deleted or changed since this skill.", view=None); return
            for entry in before:
                timer_id, old_end, old_count, old_skill = entry[:4]
                previous_update = entry[4] if len(entry)>4 else None
                db.execute("UPDATE timers SET end_ts=?,skill_count=?,last_skill_ts=?,last_update_ts=COALESCE(?,last_update_ts) WHERE id=?", (old_end,old_count,old_skill,previous_update,timer_id))
            db.execute("UPDATE skill_events SET undone=1 WHERE id=?", (event_id,))
        await interaction.response.edit_message(content=f"Undid skill event **#{event_id}** and restored {len(before)} timer(s).", view=None)
        await refresh_board(interaction.guild_id)


class UndoSkillView(discord.ui.View):
    def __init__(self, events):
        super().__init__(timeout=120)
        self.add_item(UndoSkillSelect(events))


def priority_review(guild_id):
    """Preview all active timers without modifying their durations or submission history."""
    rows = sorted_fair(all_active_rows(guild_id))
    changes = [(r, int(r["priority"]), calculated_priority(r)) for r in rows]
    return changes


class ConfirmPriorityRecalc(discord.ui.View):
    def __init__(self, owner_id):
        super().__init__(timeout=180)
        self.owner_id = owner_id

    @discord.ui.button(label="Confirm Recalculation", style=discord.ButtonStyle.success)
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.owner_id or not can_manage(interaction):
            await interaction.response.send_message("Only the manager who started this review can confirm.", ephemeral=True)
            return
        changes = priority_review(interaction.guild_id)
        updated = 0
        with connect() as db:
            for r, old, new in changes:
                if r["priority_override"]:
                    continue  # Preserve deliberate leadership overrides.
                if old != new:
                    db.execute("UPDATE timers SET priority=? WHERE id=? AND guild_id=? AND priority_override=0", (new, r["id"], interaction.guild_id))
                    updated += 1
        await interaction.response.edit_message(content=f"Recalculated {len(changes)} active timers. Updated {updated} saved priorities; manual overrides preserved. Dates, player names, and remaining times were not changed.", view=None)
        await refresh_board(interaction.guild_id)

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("Only the manager who started this review can cancel.", ephemeral=True)
            return
        await interaction.response.edit_message(content="Priority recalculation cancelled.", view=None)


async def show_priority_review(interaction):
    if not can_manage(interaction):
        await interaction.response.send_message("Only managers can recalculate priorities.", ephemeral=True)
        return
    changes = priority_review(interaction.guild_id)
    if not changes:
        await interaction.response.send_message("No active Build or Research timers found.", ephemeral=True)
        return
    lines = []
    for r, old, new in changes[:18]:
        marker = " (manual override)" if r["priority_override"] else ""
        lines.append(f"#{r['id']} {r['player']} [{r['timer_type']}] · <t:{r['created_ts']}:d> · {human_remaining(r['end_ts'])} · {priority_text(old)} → {priority_text(new)}{marker}")
    message = (f"**Priority review — {len(changes)} active timers**\n"
               "Points: 5/10/15/20 by original length, +3/day waiting, −5 per submission after 2. Skills reset waiting.\n"
               "Existing dates and timers are unchanged. Older missing history cannot be reconstructed.\n\n"
               + "\n".join(lines))
    if len(changes) > 18:
        message += f"\n...and {len(changes)-18} more. Confirm applies to ALL active timers."
    await interaction.response.send_message(message[:1950], view=ConfirmPriorityRecalc(interaction.user.id), ephemeral=True)


class HelperButtons(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Add Build", style=discord.ButtonStyle.primary, custom_id="helper:add_build")
    async def add_build(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(TimerModal("build"))

    @discord.ui.button(label="Add Research", style=discord.ButtonStyle.primary, custom_id="helper:add_research")
    async def add_research(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(TimerModal("research"))

    @discord.ui.button(label="+ Skill", style=discord.ButtonStyle.success, custom_id="helper:add_skill", row=1)
    async def add_skill(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not can_manage(interaction):
            await interaction.response.send_message("Only managers can apply skills.", ephemeral=True); return
        await interaction.response.send_message("Which skill was used?", view=SkillTypeView(), ephemeral=True)

    @discord.ui.button(label="− Skill", style=discord.ButtonStyle.danger, custom_id="helper:undo_skill", row=1)
    async def undo_skill(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not can_manage(interaction):
            await interaction.response.send_message("Only managers can undo skills.", ephemeral=True); return
        with connect() as db:
            events = db.execute("SELECT * FROM skill_events WHERE guild_id=? AND undone=0 ORDER BY id DESC LIMIT 25", (interaction.guild_id,)).fetchall()
        if not events:
            await interaction.response.send_message("No skill events to undo.", ephemeral=True); return
        await interaction.response.send_message("Select the skill event to undo:", view=UndoSkillView(events), ephemeral=True)

    @discord.ui.button(label="Review Priorities", style=discord.ButtonStyle.secondary, custom_id="helper:review_priorities", row=2)
    async def review_priorities(self, interaction: discord.Interaction, button: discord.ui.Button):
        await show_priority_review(interaction)

    @discord.ui.button(label="Manage Timer", style=discord.ButtonStyle.secondary, custom_id="helper:manage_timer")
    async def manage_timer(self, interaction: discord.Interaction, button: discord.ui.Button):
        now = int(datetime.now(timezone.utc).timestamp())
        with connect() as db:
            if can_manage(interaction):
                rows = db.execute("SELECT * FROM timers WHERE guild_id=? AND completed=0 AND end_ts>? ORDER BY priority DESC,end_ts DESC",
                                  (interaction.guild_id, now)).fetchall()
            else:
                rows = db.execute("SELECT * FROM timers WHERE guild_id=? AND (created_by=? OR owner_id=?) AND completed=0 AND end_ts>? ORDER BY priority DESC,end_ts DESC",
                                  (interaction.guild_id, interaction.user.id, interaction.user.id, now)).fetchall()
        if not rows:
            await interaction.response.send_message("You don't have any active timers to manage.", ephemeral=True); return
        await interaction.response.send_message(f"Pick a timer to manage — page 1/{(len(rows)+24)//25}:", view=TimerPickerView(rows), ephemeral=True)

    @discord.ui.button(label="My Timers", style=discord.ButtonStyle.secondary, custom_id="helper:my_timers")
    async def my_timers(self, interaction: discord.Interaction, button: discord.ui.Button):
        now = int(datetime.now(timezone.utc).timestamp())
        with connect() as db:
            rows = db.execute("SELECT * FROM timers WHERE guild_id=? AND (created_by=? OR owner_id=?) AND completed=0 AND end_ts>? ORDER BY priority DESC,end_ts DESC",
                              (interaction.guild_id, interaction.user.id, interaction.user.id, now)).fetchall()
        if not rows:
            await interaction.response.send_message("You don't have any active timers.", ephemeral=True); return
        await interaction.response.send_message(f"Your timers — page 1/{(len(rows)+24)//25}", view=TimerPickerView(rows), ephemeral=True)


class HelperBot(commands.Bot):
    async def setup_hook(self):
        init_db()
        self.add_view(HelperButtons())
        if GUILD_ID:
            guild = discord.Object(id=int(GUILD_ID)); self.tree.copy_global_to(guild=guild); await self.tree.sync(guild=guild)
            print(f"Commands synced to guild {GUILD_ID}")
        else:
            await self.tree.sync(); print("Global commands synced")


bot = HelperBot(command_prefix="!", intents=intents)


def add_timer(guild_id, player, timer_type, project, days, hours, minutes, created_by, priority=2):
    validate_timer(player, project, days, hours, minutes)
    now = datetime.now(timezone.utc); end = now + timedelta(days=days, hours=hours, minutes=minutes)
    with connect() as db:
        cur = db.execute("""INSERT INTO timers(guild_id, player, timer_type, project, end_ts, created_by, created_ts, priority)
                            VALUES(?,?,?,?,?,?,?,?)""",
                         (guild_id, player.strip(), timer_type, project.strip(), int(end.timestamp()), created_by, int(now.timestamp()), priority))
        timer_id=cur.lastrowid
        db.execute("UPDATE timers SET original_seconds=?,last_update_ts=?,owner_id=? WHERE id=?",(max(0,int(end.timestamp())-int(now.timestamp())),int(now.timestamp()),created_by,timer_id))
        return timer_id, int(end.timestamp())


@app_commands.guild_only()
@bot.tree.command(name="addbuild", description="Add a construction timer.")
async def addbuild(interaction: discord.Interaction, player: str, days: app_commands.Range[int,0,3650], project: str="Power Plant",
                   hours: app_commands.Range[int,0,23]=0, minutes: app_commands.Range[int,0,59]=0):
    await interaction.response.defer(ephemeral=True, thinking=True)
    try:
        timer_id,end_ts=add_timer(interaction.guild_id,player,"build",project,days,hours,minutes,interaction.user.id)
    except ValueError as exc:
        await interaction.followup.send(str(exc), ephemeral=True)
        return
    except Exception:
        logging.exception("Failed to add build timer")
        await interaction.followup.send("Could not save timer. Check the server log.", ephemeral=True)
        return
    await interaction.followup.send(f"Saved **#{timer_id} {player}** — {project} — ends <t:{end_ts}:R>. Find it in /timers.",ephemeral=True)
    try: await refresh_board(interaction.guild_id)
    except Exception: logging.exception("Board refresh failed after timer save")


@app_commands.guild_only()
@bot.tree.command(name="addresearch", description="Add a research timer.")
async def addresearch(interaction: discord.Interaction, player: str, days: app_commands.Range[int,0,3650], project: str="Research",
                      hours: app_commands.Range[int,0,23]=0, minutes: app_commands.Range[int,0,59]=0):
    await interaction.response.defer(ephemeral=True, thinking=True)
    try:
        timer_id,end_ts=add_timer(interaction.guild_id,player,"research",project,days,hours,minutes,interaction.user.id)
    except ValueError as exc:
        await interaction.followup.send(str(exc), ephemeral=True)
        return
    except Exception:
        logging.exception("Failed to add research timer")
        await interaction.followup.send("Could not save timer. Check the server log.", ephemeral=True)
        return
    await interaction.followup.send(f"Saved **#{timer_id} {player}** — {project} — ends <t:{end_ts}:R>. Find it in /timers.",ephemeral=True)
    try: await refresh_board(interaction.guild_id)
    except Exception: logging.exception("Board refresh failed after timer save")


@app_commands.guild_only()
@bot.tree.command(name="helpers", description="Show the current helper priority list.")
async def helpers(interaction: discord.Interaction):
    await interaction.response.send_message(embed=make_board_embed(interaction.guild_id))


@app_commands.guild_only()
@bot.tree.command(name="timers", description="Show all active timers, including below-threshold timers.")
async def timers(interaction: discord.Interaction, category: str = "all", page: app_commands.Range[int,1,999] = 1):
    if category.lower() not in ("all", "build", "research"):
        await interaction.response.send_message("Category must be all, build or research.", ephemeral=True)
        return
    rows = sorted_fair(all_active_rows(interaction.guild_id))
    if category.lower() != "all":
        rows = [r for r in rows if r["timer_type"] == category.lower()]
    pages = max(1, (len(rows)+9)//10)
    if page > pages:
        await interaction.response.send_message(f"Only {pages} page(s) available.", ephemeral=True)
        return
    lines = [compact_timer_line(r, show_category=True) for r in rows[(page-1)*10:page*10]]
    await interaction.response.send_message(f"**Active timers — {category} — page {page}/{pages} ({len(rows)} total)**\n" + ("\n".join(lines) or "No active timers."), ephemeral=True)



@app_commands.guild_only()
@bot.tree.command(name="priority", description="Set a timer's helper priority.")
@app_commands.choices(level=[app_commands.Choice(name="URGENT",value=40),app_commands.Choice(name="HIGH",value=30),app_commands.Choice(name="NORMAL",value=20),app_commands.Choice(name="LOW",value=10)])
async def priority(interaction: discord.Interaction, timer_id: int, level: app_commands.Choice[int]):
    with connect() as db:
        row=db.execute("SELECT * FROM timers WHERE id=? AND guild_id=?",(timer_id,interaction.guild_id)).fetchone()
        if not row: await interaction.response.send_message("I couldn't find that timer.",ephemeral=True); return
        if not row_accessible(interaction,row): await interaction.response.send_message("You can only prioritize your own timers. Managers can change any.",ephemeral=True); return
        if not can_manage(interaction): await interaction.response.send_message("Only managers can override automatic priority.",ephemeral=True); return
        db.execute("UPDATE timers SET priority=?,priority_override=1 WHERE id=?",(level.value,timer_id))
    await interaction.response.send_message(f"**#{timer_id} {row['player']}** → {priority_text(level.value)}",ephemeral=True); await refresh_board(interaction.guild_id)


@app_commands.guild_only()
@bot.tree.command(name="updatetime", description="Update remaining time on a timer.")
async def updatetime(interaction: discord.Interaction, timer_id:int, days:app_commands.Range[int,0,3650], hours:app_commands.Range[int,0,23]=0, minutes:app_commands.Range[int,0,59]=0):
    with connect() as db:
        row=db.execute("SELECT * FROM timers WHERE id=? AND guild_id=?",(timer_id,interaction.guild_id)).fetchone()
        if not row: await interaction.response.send_message("I couldn't find that timer.",ephemeral=True); return
        if not row_accessible(interaction,row): await interaction.response.send_message("You can only update your own timers.",ephemeral=True); return
        new_end_ts=int((datetime.now(timezone.utc)+timedelta(days=days,hours=hours,minutes=minutes)).timestamp())
        db.execute("UPDATE timers SET end_ts=?,completed=0,last_update_ts=? WHERE id=?",(new_end_ts,int(datetime.now(timezone.utc).timestamp()),timer_id))
    await interaction.response.send_message(f"Updated **#{timer_id}** to **{days}d {hours}h {minutes}m** remaining.",ephemeral=True); await refresh_board(interaction.guild_id)


@app_commands.guild_only()
@bot.tree.command(name="done", description="Mark a timer complete.")
async def done(interaction: discord.Interaction, timer_id:int):
    with connect() as db:
        row=db.execute("SELECT * FROM timers WHERE id=? AND guild_id=?",(timer_id,interaction.guild_id)).fetchone()
        if not row: await interaction.response.send_message("I couldn't find that timer.",ephemeral=True); return
        if not row_accessible(interaction,row): await interaction.response.send_message("You can only finish your own timers.",ephemeral=True); return
        db.execute("UPDATE timers SET completed=1 WHERE id=?",(timer_id,))
    await interaction.response.send_message(f"Timer **#{timer_id}** marked complete.",ephemeral=True); await refresh_board(interaction.guild_id)


@app_commands.guild_only()
@bot.tree.command(name="remove", description="Permanently delete a timer.")
async def remove(interaction: discord.Interaction, timer_id:int):
    with connect() as db:
        row=db.execute("SELECT * FROM timers WHERE id=? AND guild_id=?",(timer_id,interaction.guild_id)).fetchone()
        if not row: await interaction.response.send_message("I couldn't find that timer.",ephemeral=True); return
        if not row_accessible(interaction,row): await interaction.response.send_message("You can only delete your own timers.",ephemeral=True); return
        db.execute("DELETE FROM timers WHERE id=?",(timer_id,))
    await interaction.response.send_message(f"Timer **#{timer_id}** permanently deleted.",ephemeral=True); await refresh_board(interaction.guild_id)


@app_commands.guild_only()
@bot.tree.command(name="stats", description="Show a quick Bob helper-board summary.")
async def stats(interaction: discord.Interaction):
    now=int(datetime.now(timezone.utc).timestamp())
    with connect() as db:
        active=db.execute("SELECT COUNT(*) c FROM timers WHERE guild_id=? AND completed=0 AND end_ts>?",(interaction.guild_id,now)).fetchone()["c"]
        builds=db.execute("SELECT COUNT(*) c FROM timers WHERE guild_id=? AND completed=0 AND timer_type='build' AND end_ts>?",(interaction.guild_id,now)).fetchone()["c"]
        research=db.execute("SELECT COUNT(*) c FROM timers WHERE guild_id=? AND completed=0 AND timer_type='research' AND end_ts>?",(interaction.guild_id,now)).fetchone()["c"]
        urgent=sum(calculated_priority(r)>=40 for r in all_active_rows(interaction.guild_id))
    await interaction.response.send_message(f"**Bob Stats**\nActive: **{active}** · Builds: **{builds}** · Research: **{research}** · Urgent: **{urgent}**",ephemeral=True)


@app_commands.guild_only()
@bot.tree.command(name="cleanup", description="Archive expired timers without deleting records.")
@app_commands.checks.has_permissions(manage_guild=True)
async def cleanup(interaction: discord.Interaction):
    now=int(datetime.now(timezone.utc).timestamp())
    with connect() as db:
        cur=db.execute("UPDATE timers SET completed=1 WHERE guild_id=? AND completed=0 AND end_ts<=?",(interaction.guild_id,now)); n=cur.rowcount
    await interaction.response.send_message(f"Archived **{n}** expired timer(s); no player records were deleted.",ephemeral=True); await refresh_board(interaction.guild_id)


@app_commands.guild_only()
@bot.tree.command(name="board", description="Create/move the auto-updating helper board to this channel.")
@app_commands.checks.has_permissions(manage_guild=True)
async def board(interaction: discord.Interaction):
    await interaction.response.defer(ephemeral=True)
    message=await interaction.channel.send(embed=make_board_embed(interaction.guild_id),view=HelperButtons())
    with connect() as db:
        db.execute("""INSERT INTO boards(guild_id,channel_id,message_id) VALUES(?,?,?)
                    ON CONFLICT(guild_id) DO UPDATE SET channel_id=excluded.channel_id,message_id=excluded.message_id""",
                   (interaction.guild_id,interaction.channel_id,message.id))
    await interaction.followup.send("Bob's auto-updating priority board is live in this channel.",ephemeral=True)


@app_commands.guild_only()
@bot.tree.command(name="seedcurrent", description="Load the supplied 9/10 build/research list.")
@app_commands.checks.has_permissions(manage_guild=True)
async def seedcurrent(interaction: discord.Interaction):
    with connect() as db:
        count=db.execute("SELECT COUNT(*) c FROM timers WHERE guild_id=?",(interaction.guild_id,)).fetchone()["c"]
        if count: await interaction.response.send_message("This server already has timers, so I didn't create duplicates.",ephemeral=True); return
        seed_start=datetime(2026,9,10,17,41,tzinfo=timezone.utc)
        entries=[("B3ndm3ov3r","build","Power Plant",11),("Tomcat","build","Power Plant",24),("GabrielValeriote","build","Power Plant",14),("Kickflip","build","Power Plant",19),("Advent","build","Power Plant",18),("Winry","build","Construction",22),("Winry","research","Research Timer 1",55),("Winry","research","Research Timer 2",19)]
        created_ts=int(datetime.now(timezone.utc).timestamp())
        for player,timer_type,project,days in entries:
            end_ts=int((seed_start+timedelta(days=days)).timestamp())
            db.execute("INSERT INTO timers(guild_id,player,timer_type,project,end_ts,created_by,created_ts,priority,original_seconds,last_update_ts) VALUES(?,?,?,?,?,?,?,?,?,?)",(interaction.guild_id,player,timer_type,project,end_ts,interaction.user.id,created_ts,2,max(0,end_ts-created_ts),created_ts))
    await interaction.response.send_message("Loaded the 9/10 helper list with NORMAL priority.",ephemeral=True); await refresh_board(interaction.guild_id)


@app_commands.guild_only()
@bot.tree.command(name="skill", description="Apply a 5%, 10%, or 15% skill to all active timers of one player and type.")
@app_commands.choices(timer_type=[app_commands.Choice(name="Build",value="build"),app_commands.Choice(name="Research",value="research")])
async def skill(interaction: discord.Interaction, player: str, timer_type: app_commands.Choice[str], percent: int = 15, timer_id: int = 0):
    if not can_manage(interaction):
        await interaction.response.send_message("Only managers can record skill usage.",ephemeral=True); return
    if percent not in (5, 10, 15):
        await interaction.response.send_message("Choose 5, 10, or 15 percent.", ephemeral=True); return
    event_id,count=apply_skill(interaction.guild_id,interaction.user.id,timer_type.value,player,percent,timer_id or None)
    if not count: await interaction.response.send_message("No active matching timers found.",ephemeral=True); return
    await interaction.response.send_message(f"Applied {percent}% {timer_type.value} skill to **{count}** active timer(s) for **{player}**. Event **#{event_id}**; use `/undoskill` if mistaken.",ephemeral=True)
    await refresh_board(interaction.guild_id)


@app_commands.guild_only()
@bot.tree.command(name="undoskill", description="Undo a recorded skill event, restoring each affected timer.")
@app_commands.checks.has_permissions(manage_guild=True)
async def undoskill(interaction: discord.Interaction, event_id: int):
    with connect() as db:
        ev=db.execute("SELECT * FROM skill_events WHERE id=? AND guild_id=? AND undone=0",(event_id,interaction.guild_id)).fetchone()
        if not ev: await interaction.response.send_message("Event not found or already undone.",ephemeral=True); return
        # Refuse unsafe undo when a later skill touched any affected timer.
        before=json.loads(ev["before_json"])
        for entry in before:
            timer_id,old_end,old_count,old_skill=entry[:4]
            r=db.execute("SELECT * FROM timers WHERE id=? AND guild_id=?",(timer_id,interaction.guild_id)).fetchone()
            expected_end=ev["event_ts"]+max(0,old_end-ev["event_ts"]-math.ceil(max(0,old_end-ev["event_ts"])*ev["percent"]/100))
            if not r or r["last_skill_ts"]!=ev["event_ts"] or r["skill_count"]!=old_count+1 or r["end_ts"]!=expected_end or (len(entry)>4 and r["last_update_ts"]!=ev["event_ts"]):
                await interaction.response.send_message("Cannot safely undo: one or more timers were deleted or received later changes.",ephemeral=True); return
        for entry in before:
            timer_id,old_end,old_count,old_skill=entry[:4]
            db.execute("UPDATE timers SET end_ts=?,skill_count=?,last_skill_ts=?,last_update_ts=COALESCE(?,last_update_ts) WHERE id=?",(old_end,old_count,old_skill,entry[4] if len(entry)>4 else None,timer_id))
        db.execute("UPDATE skill_events SET undone=1 WHERE id=?",(event_id,))
    await interaction.response.send_message(f"Undid skill event **#{event_id}** for {len(before)} timers.",ephemeral=True)
    await refresh_board(interaction.guild_id)


@app_commands.guild_only()
@bot.tree.command(name="skillhistory", description="View recent skill events and event IDs for undo.")
async def skillhistory(interaction: discord.Interaction):
    with connect() as db:
        rows=db.execute("SELECT * FROM skill_events WHERE guild_id=? ORDER BY id DESC LIMIT 15",(interaction.guild_id,)).fetchall()
    msg="\n".join(f"#{r['id']} {r['player']} · {r['timer_type']} · <t:{r['event_ts']}:R>{' (undone)' if r['undone'] else ''}" for r in rows)
    await interaction.response.send_message(msg or "No skill events yet.",ephemeral=True)


@app_commands.guild_only()
@bot.tree.command(name="setreminder", description="Configure the daily 00:00 UTC reset reminder in this channel.")
@app_commands.checks.has_permissions(manage_guild=True)
async def setreminder(interaction: discord.Interaction, enabled: bool=True, role: discord.Role=None):
    with connect() as db:
        db.execute("""INSERT INTO reminder_settings(guild_id,channel_id,role_id,enabled) VALUES(?,?,?,?)
            ON CONFLICT(guild_id) DO UPDATE SET channel_id=excluded.channel_id,role_id=excluded.role_id,enabled=excluded.enabled""",
            (interaction.guild_id,interaction.channel_id,role.id if role else None,int(enabled)))
    await interaction.response.send_message(f"Daily reminder {'enabled' if enabled else 'disabled'} in this channel at **00:00 UTC**." + (f" Ping: {role.mention}" if role else " No role ping."),ephemeral=True)


@app_commands.guild_only()
@bot.tree.command(name="recalculatepriorities", description="Preview and update all existing Build and Research priorities.")
async def recalculatepriorities(interaction: discord.Interaction):
    await show_priority_review(interaction)


@app_commands.guild_only()
@bot.tree.command(name="dashboard", description="Admin review of stale timers and current fairness ranking.")
@app_commands.checks.has_permissions(manage_guild=True)
async def dashboard(interaction: discord.Interaction):
    now=int(datetime.now(timezone.utc).timestamp())
    rows=sorted_fair(all_active_rows(interaction.guild_id))
    stale=[r for r in rows if now-r["last_update_ts"]>=7*86400]
    lines=[f"{priority_text(calculated_priority(r))} #{r['id']} {r['player']} {r['timer_type']} · {timer_details(r)}" for r in rows[:15]]
    await interaction.response.send_message(f"**Active:** {len(rows)} · **Need review (7d):** {len(stale)}\n"+"\n".join(lines)[:1700],ephemeral=True)


@board.error
@setreminder.error
@undoskill.error
@dashboard.error
@cleanup.error
@seedcurrent.error
async def admin_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
    if isinstance(error, app_commands.MissingPermissions):
        msg="You need **Manage Server** permission for that command."
        if interaction.response.is_done(): await interaction.followup.send(msg,ephemeral=True)
        else: await interaction.response.send_message(msg,ephemeral=True)
    else: raise error


@tasks.loop(minutes=REFRESH_MINUTES)
async def auto_refresh():
    with connect() as db: guild_ids=[r["guild_id"] for r in db.execute("SELECT guild_id FROM boards").fetchall()]
    for guild_id in guild_ids:
        await refresh_board(guild_id); await asyncio.sleep(1)


@tasks.loop(minutes=1)
async def daily_reset_reminder():
    now=datetime.now(timezone.utc)
    if now.hour != 0 or now.minute > 2: return
    day=now.date().isoformat()
    with connect() as db:
        configs=db.execute("SELECT * FROM reminder_settings WHERE enabled=1 AND (last_sent_day IS NULL OR last_sent_day!=?)",(day,)).fetchall()
    for conf in configs:
        channel=bot.get_channel(conf["channel_id"])
        if channel is None:
            try: channel=await bot.fetch_channel(conf["channel_id"])
            except discord.DiscordException: continue
        role_id=conf["role_id"]
        mention=f"<@&{role_id}> " if role_id else ""
        try:
            await channel.send(mention+"**Bob the Builder — Daily Reset (00:00 UTC)**\nUpdate your build/research timers, add new projects, and mark finished timers complete. Accurate timers keep skill help fair.",allowed_mentions=discord.AllowedMentions(roles=bool(role_id)))
        except discord.DiscordException: continue
        with connect() as db:
            db.execute("UPDATE reminder_settings SET last_sent_day=? WHERE guild_id=?",(day,conf["guild_id"]))


@daily_reset_reminder.before_loop
async def before_daily_reset_reminder(): await bot.wait_until_ready()


@auto_refresh.before_loop
async def before_auto_refresh(): await bot.wait_until_ready()


@bot.event
async def on_ready():
    print(f"Logged in as {bot.user} (ID: {bot.user.id})")
    if not auto_refresh.is_running(): auto_refresh.start()
    if not daily_reset_reminder.is_running(): daily_reset_reminder.start()


if __name__ == "__main__":
    if not TOKEN: raise RuntimeError("DISCORD_TOKEN is missing. Copy .env.example to .env and paste your bot token.")
    bot.run(TOKEN)
