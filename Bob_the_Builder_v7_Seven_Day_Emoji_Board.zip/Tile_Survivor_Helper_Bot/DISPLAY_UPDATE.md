# Display update
- Public priority board only displays timers with at least 7 days (168 hours) remaining.
- Timers under 7 days stay in SQLite and remain visible through `/timers` and management controls.
- Compact lines show only priority emoji, time remaining, player, MM/DD submission date, waiting days and per-timer skill count.
- No submission number or priority level name in the compact timer line.
- Build and Research remain separate sections.
