import os
import sqlite3
import asyncio
from datetime import datetime, timedelta, timezone

import discord
from discord import app_commands
from discord.ext import commands, tasks
from dotenv import load_dotenv

load_dotenv()

TOKEN = os.getenv("DISCORD_TOKEN")
GUILD_ID = os.getenv("GUILD_ID")
DB_PATH = os.getenv("DB_PATH", "helper_bot.db")
BUILD_THRESHOLD_DAYS = float(os.getenv("BUILD_THRESHOLD_DAYS", "10"))
RESEARCH_THRESHOLD_DAYS = float(os.getenv("RESEARCH_THRESHOLD_DAYS", "7"))
REFRESH_MINUTES = int(os.getenv("REFRESH_MINUTES", "10"))

intents = discord.Intents.default()

PRIORITIES = {
    4: ("URGENT", "🔴"),
    3: ("HIGH", "🟠"),
    2: ("NORMAL", "🟡"),
    1: ("LOW", "🟢"),
}


def connect():
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    return db


def init_db():
    with connect() as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS timers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id INTEGER NOT NULL,
                player TEXT NOT NULL,
                timer_type TEXT NOT NULL CHECK(timer_type IN ('build','research')),
                project TEXT NOT NULL,
                end_ts INTEGER NOT NULL,
                created_by INTEGER,
                created_ts INTEGER NOT NULL,
                completed INTEGER NOT NULL DEFAULT 0,
                priority INTEGER NOT NULL DEFAULT 2
            )
        """)
        cols = {r["name"] for r in db.execute("PRAGMA table_info(timers)").fetchall()}
        if "priority" not in cols:
            db.execute("ALTER TABLE timers ADD COLUMN priority INTEGER NOT NULL DEFAULT 2")
        db.execute("""
            CREATE TABLE IF NOT EXISTS boards (
                guild_id INTEGER PRIMARY KEY,
                channel_id INTEGER NOT NULL,
                message_id INTEGER NOT NULL
            )
        """)


def human_remaining(end_ts: int) -> str:
    seconds = max(0, end_ts - int(datetime.now(timezone.utc).timestamp()))
    days, rem = divmod(seconds, 86400)
    hours, rem = divmod(rem, 3600)
    minutes = rem // 60
    if days:
        return f"{days}d {hours}h"
    if hours:
        return f"{hours}h {minutes}m"
    return f"{minutes}m"


def priority_text(value: int) -> str:
    label, icon = PRIORITIES.get(int(value or 2), PRIORITIES[2])
    return f"{icon} {label}"


def qualifying_rows(guild_id: int):
    now = int(datetime.now(timezone.utc).timestamp())
    build_cutoff = now + int(BUILD_THRESHOLD_DAYS * 86400)
    research_cutoff = now + int(RESEARCH_THRESHOLD_DAYS * 86400)
    with connect() as db:
        builds = db.execute("""
            SELECT * FROM timers
            WHERE guild_id=? AND completed=0 AND timer_type='build' AND end_ts > ?
            ORDER BY priority DESC, end_ts DESC
        """, (guild_id, build_cutoff)).fetchall()
        research = db.execute("""
            SELECT * FROM timers
            WHERE guild_id=? AND completed=0 AND timer_type='research' AND end_ts > ?
            ORDER BY priority DESC, end_ts DESC
        """, (guild_id, research_cutoff)).fetchall()
    return builds, research


def all_active_rows(guild_id: int):
    now = int(datetime.now(timezone.utc).timestamp())
    with connect() as db:
        return db.execute("""
            SELECT * FROM timers
            WHERE guild_id=? AND completed=0 AND end_ts > ?
            ORDER BY priority DESC, timer_type, end_ts DESC
        """, (guild_id, now)).fetchall()


def make_board_embed(guild_id: int) -> discord.Embed:
    builds, research = qualifying_rows(guild_id)
    embed = discord.Embed(
        title="Bob the Builder — Helper Priority Board",
        description=(
            f"Season Skill targets: **builds over {BUILD_THRESHOLD_DAYS:g} days** and "
            f"**research over {RESEARCH_THRESHOLD_DAYS:g} days**.\n"
            "Priority overrides timer length, then longest timers appear first."
        ),
        timestamp=datetime.now(timezone.utc),
    )

    def lines_for(rows):
        return [
            f"{priority_text(r['priority'])}  **#{r['id']} · {r['player']}** — {human_remaining(r['end_ts'])}\n"
            f"{r['project']} · ends <t:{r['end_ts']}:R>"
            for r in rows
        ]

    embed.add_field(
        name="Construction Priority",
        value="\n\n".join(lines_for(builds))[:1024] if builds else "No qualifying build timers right now.",
        inline=False,
    )
    embed.add_field(
        name="Research Priority",
        value="\n\n".join(lines_for(research))[:1024] if research else "No qualifying research timers right now.",
        inline=False,
    )
    embed.set_footer(text=f"Auto-refresh: {REFRESH_MINUTES} min · Add, manage, prioritize, finish, or delete with buttons")
    return embed


def can_manage(interaction: discord.Interaction) -> bool:
    return bool(
        interaction.guild
        and isinstance(interaction.user, discord.Member)
        and (interaction.user.guild_permissions.manage_guild or interaction.user.guild_permissions.administrator)
    )


def row_accessible(interaction: discord.Interaction, row) -> bool:
    return bool(row and (row["created_by"] == interaction.user.id or can_manage(interaction)))


async def refresh_board(guild_id: int):
    with connect() as db:
        board_row = db.execute("SELECT * FROM boards WHERE guild_id=?", (guild_id,)).fetchone()
    if not board_row:
        return
    channel = bot.get_channel(board_row["channel_id"])
    if channel is None:
        try:
            channel = await bot.fetch_channel(board_row["channel_id"])
        except discord.DiscordException:
            return
    try:
        msg = await channel.fetch_message(board_row["message_id"])
        await msg.edit(embed=make_board_embed(guild_id), view=HelperButtons())
    except discord.NotFound:
        with connect() as db:
            db.execute("DELETE FROM boards WHERE guild_id=?", (guild_id,))
    except discord.DiscordException:
        pass


class TimerModal(discord.ui.Modal):
    def __init__(self, timer_type: str, edit_row=None):
        self.timer_type = timer_type
        self.edit_row = edit_row
        super().__init__(title=(f"Edit {timer_type.title()} Timer" if edit_row else f"Add {timer_type.title()} Timer"))
        now_ts = int(datetime.now(timezone.utc).timestamp())
        remain = max(0, edit_row["end_ts"] - now_ts) if edit_row else 0
        days_default = str(remain // 86400) if edit_row else ""
        hours_default = str((remain % 86400) // 3600) if edit_row else "0"
        self.player = discord.ui.TextInput(label="Player name", default=edit_row["player"] if edit_row else "", max_length=50)
        self.project = discord.ui.TextInput(
            label="Build / Research",
            default=edit_row["project"] if edit_row else ("Power Plant" if timer_type == "build" else "Research"),
            max_length=80,
        )
        self.days = discord.ui.TextInput(label="Days remaining", placeholder="Example: 24", default=days_default, max_length=4)
        self.hours = discord.ui.TextInput(label="Hours remaining (0-23)", placeholder="0", default=hours_default, required=False, max_length=2)
        self.add_item(self.player); self.add_item(self.project); self.add_item(self.days); self.add_item(self.hours)

    async def on_submit(self, interaction: discord.Interaction):
        try:
            days = int(self.days.value or 0); hours = int(self.hours.value or 0)
            if days < 0 or hours < 0 or hours > 23: raise ValueError
        except ValueError:
            await interaction.response.send_message("Enter valid days and hours (hours must be 0–23).", ephemeral=True)
            return
        now = datetime.now(timezone.utc)
        end_ts = int((now + timedelta(days=days, hours=hours)).timestamp())
        if self.edit_row:
            with connect() as db:
                db.execute("UPDATE timers SET player=?, project=?, timer_type=?, end_ts=?, completed=0 WHERE id=?",
                           (self.player.value.strip(), self.project.value.strip(), self.timer_type, end_ts, self.edit_row["id"]))
            msg = f"Updated **#{self.edit_row['id']} {self.player.value}** to **{days}d {hours}h** remaining."
        else:
            with connect() as db:
                cur = db.execute("""INSERT INTO timers(guild_id, player, timer_type, project, end_ts, created_by, created_ts, priority)
                                    VALUES(?,?,?,?,?,?,?,2)""",
                                 (interaction.guild_id, self.player.value.strip(), self.timer_type, self.project.value.strip(), end_ts,
                                  interaction.user.id, int(now.timestamp())))
                timer_id = cur.lastrowid
            msg = f"Added **#{timer_id} {self.player.value}** — **{days}d {hours}h** remaining · priority NORMAL."
        await interaction.response.send_message(msg, ephemeral=True)
        await refresh_board(interaction.guild_id)


class TimerSelect(discord.ui.Select):
    def __init__(self, rows):
        options = [discord.SelectOption(
            label=f"#{r['id']} {r['player']}"[:100],
            description=f"{priority_text(r['priority'])} · {r['timer_type'].title()} · {human_remaining(r['end_ts'])}"[:100],
            value=str(r["id"]),
        ) for r in rows[:25]]
        super().__init__(placeholder="Choose a timer to manage…", options=options)

    async def callback(self, interaction: discord.Interaction):
        timer_id = int(self.values[0])
        with connect() as db:
            row = db.execute("SELECT * FROM timers WHERE id=? AND guild_id=?", (timer_id, interaction.guild_id)).fetchone()
        if not row:
            await interaction.response.send_message("That timer no longer exists.", ephemeral=True); return
        if not row_accessible(interaction, row):
            await interaction.response.send_message("You can only manage your own timers.", ephemeral=True); return
        await interaction.response.edit_message(
            content=f"Managing **#{row['id']} {row['player']}** · {priority_text(row['priority'])} · {row['project']} · {human_remaining(row['end_ts'])}",
            view=TimerActionsView(row),
        )


class TimerPickerView(discord.ui.View):
    def __init__(self, rows):
        super().__init__(timeout=120)
        self.add_item(TimerSelect(rows))


class PrioritySelect(discord.ui.Select):
    def __init__(self, timer_id: int):
        self.timer_id = timer_id
        options = [
            discord.SelectOption(label="URGENT", description="Top of the helper list", value="4", emoji="🔴"),
            discord.SelectOption(label="HIGH", description="Above normal priority", value="3", emoji="🟠"),
            discord.SelectOption(label="NORMAL", description="Default priority", value="2", emoji="🟡"),
            discord.SelectOption(label="LOW", description="Lowest priority", value="1", emoji="🟢"),
        ]
        super().__init__(placeholder="Set priority…", options=options)

    async def callback(self, interaction: discord.Interaction):
        with connect() as db:
            row = db.execute("SELECT * FROM timers WHERE id=? AND guild_id=?", (self.timer_id, interaction.guild_id)).fetchone()
            if not row_accessible(interaction, row):
                await interaction.response.send_message("You can't change that timer.", ephemeral=True); return
            p = int(self.values[0])
            db.execute("UPDATE timers SET priority=? WHERE id=?", (p, self.timer_id))
        await interaction.response.edit_message(content=f"Priority for **#{self.timer_id} {row['player']}** set to {priority_text(p)}.", view=None)
        await refresh_board(interaction.guild_id)


class PriorityView(discord.ui.View):
    def __init__(self, timer_id: int):
        super().__init__(timeout=60)
        self.add_item(PrioritySelect(timer_id))


class ConfirmDeleteView(discord.ui.View):
    def __init__(self, timer_id: int):
        super().__init__(timeout=45)
        self.timer_id = timer_id

    @discord.ui.button(label="Yes, Delete", style=discord.ButtonStyle.danger)
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
        with connect() as db:
            row = db.execute("SELECT * FROM timers WHERE id=? AND guild_id=?", (self.timer_id, interaction.guild_id)).fetchone()
            if not row_accessible(interaction, row):
                await interaction.response.send_message("You can't delete that timer.", ephemeral=True); return
            db.execute("DELETE FROM timers WHERE id=?", (self.timer_id,))
        await interaction.response.edit_message(content=f"Deleted timer **#{self.timer_id}**.", view=None)
        await refresh_board(interaction.guild_id)

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(content="Delete cancelled.", view=None)


class TimerActionsView(discord.ui.View):
    def __init__(self, row):
        super().__init__(timeout=90)
        self.timer_id = row["id"]
        self.timer_type = row["timer_type"]

    async def fetch_access(self, interaction):
        with connect() as db:
            row = db.execute("SELECT * FROM timers WHERE id=? AND guild_id=?", (self.timer_id, interaction.guild_id)).fetchone()
        return row if row_accessible(interaction, row) else None

    @discord.ui.button(label="Edit", style=discord.ButtonStyle.primary)
    async def edit(self, interaction: discord.Interaction, button: discord.ui.Button):
        row = await self.fetch_access(interaction)
        if not row: await interaction.response.send_message("That timer isn't available to you.", ephemeral=True); return
        await interaction.response.send_modal(TimerModal(row["timer_type"], edit_row=row))

    @discord.ui.button(label="Priority", style=discord.ButtonStyle.secondary)
    async def priority(self, interaction: discord.Interaction, button: discord.ui.Button):
        row = await self.fetch_access(interaction)
        if not row: await interaction.response.send_message("That timer isn't available to you.", ephemeral=True); return
        await interaction.response.edit_message(content=f"Set priority for **#{self.timer_id} {row['player']}**:", view=PriorityView(self.timer_id))

    @discord.ui.button(label="Done", style=discord.ButtonStyle.success)
    async def done(self, interaction: discord.Interaction, button: discord.ui.Button):
        row = await self.fetch_access(interaction)
        if not row: await interaction.response.send_message("That timer isn't available to you.", ephemeral=True); return
        with connect() as db: db.execute("UPDATE timers SET completed=1 WHERE id=?", (self.timer_id,))
        await interaction.response.edit_message(content=f"Marked **#{self.timer_id} {row['player']}** complete.", view=None)
        await refresh_board(interaction.guild_id)

    @discord.ui.button(label="Delete", style=discord.ButtonStyle.danger)
    async def delete(self, interaction: discord.Interaction, button: discord.ui.Button):
        row = await self.fetch_access(interaction)
        if not row: await interaction.response.send_message("That timer isn't available to you.", ephemeral=True); return
        await interaction.response.edit_message(content=f"Delete **#{self.timer_id} {row['player']}** permanently?", view=ConfirmDeleteView(self.timer_id))


class HelperButtons(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Add Build", style=discord.ButtonStyle.primary, custom_id="helper:add_build")
    async def add_build(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(TimerModal("build"))

    @discord.ui.button(label="Add Research", style=discord.ButtonStyle.primary, custom_id="helper:add_research")
    async def add_research(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(TimerModal("research"))

    @discord.ui.button(label="Manage Timer", style=discord.ButtonStyle.secondary, custom_id="helper:manage_timer")
    async def manage_timer(self, interaction: discord.Interaction, button: discord.ui.Button):
        now = int(datetime.now(timezone.utc).timestamp())
        with connect() as db:
            if can_manage(interaction):
                rows = db.execute("SELECT * FROM timers WHERE guild_id=? AND completed=0 AND end_ts>? ORDER BY priority DESC,end_ts DESC LIMIT 25",
                                  (interaction.guild_id, now)).fetchall()
            else:
                rows = db.execute("SELECT * FROM timers WHERE guild_id=? AND created_by=? AND completed=0 AND end_ts>? ORDER BY priority DESC,end_ts DESC LIMIT 25",
                                  (interaction.guild_id, interaction.user.id, now)).fetchall()
        if not rows:
            await interaction.response.send_message("You don't have any active timers to manage.", ephemeral=True); return
        await interaction.response.send_message("Pick a timer. You can edit it, change priority, mark it done, or delete it:", view=TimerPickerView(rows), ephemeral=True)

    @discord.ui.button(label="My Timers", style=discord.ButtonStyle.secondary, custom_id="helper:my_timers")
    async def my_timers(self, interaction: discord.Interaction, button: discord.ui.Button):
        now = int(datetime.now(timezone.utc).timestamp())
        with connect() as db:
            rows = db.execute("SELECT * FROM timers WHERE guild_id=? AND created_by=? AND completed=0 AND end_ts>? ORDER BY priority DESC,end_ts DESC LIMIT 20",
                              (interaction.guild_id, interaction.user.id, now)).fetchall()
        if not rows:
            await interaction.response.send_message("You don't have any active timers.", ephemeral=True); return
        text = "\n".join(f"{priority_text(r['priority'])} **#{r['id']} {r['player']}** · {r['timer_type'].title()} · {r['project']} · {human_remaining(r['end_ts'])}" for r in rows)
        await interaction.response.send_message(text[:1900], ephemeral=True)


class HelperBot(commands.Bot):
    async def setup_hook(self):
        init_db()
        self.add_view(HelperButtons())
        if GUILD_ID:
            guild = discord.Object(id=int(GUILD_ID)); self.tree.copy_global_to(guild=guild); await self.tree.sync(guild=guild)
            print(f"Commands synced to guild {GUILD_ID}")
        else:
            await self.tree.sync(); print("Global commands synced")


bot = HelperBot(command_prefix="!", intents=intents)


def add_timer(guild_id, player, timer_type, project, days, hours, minutes, created_by, priority=2):
    now = datetime.now(timezone.utc); end = now + timedelta(days=days, hours=hours, minutes=minutes)
    with connect() as db:
        cur = db.execute("""INSERT INTO timers(guild_id, player, timer_type, project, end_ts, created_by, created_ts, priority)
                            VALUES(?,?,?,?,?,?,?,?)""",
                         (guild_id, player.strip(), timer_type, project.strip(), int(end.timestamp()), created_by, int(now.timestamp()), priority))
        return cur.lastrowid, int(end.timestamp())


@app_commands.guild_only()
@bot.tree.command(name="addbuild", description="Add a construction timer.")
async def addbuild(interaction: discord.Interaction, player: str, days: app_commands.Range[int,0,3650], project: str="Power Plant",
                   hours: app_commands.Range[int,0,23]=0, minutes: app_commands.Range[int,0,59]=0):
    timer_id,end_ts=add_timer(interaction.guild_id,player,"build",project,days,hours,minutes,interaction.user.id)
    await interaction.response.send_message(f"Added **#{timer_id} {player}** — {project} — ends <t:{end_ts}:R>.",ephemeral=True); await refresh_board(interaction.guild_id)


@app_commands.guild_only()
@bot.tree.command(name="addresearch", description="Add a research timer.")
async def addresearch(interaction: discord.Interaction, player: str, days: app_commands.Range[int,0,3650], project: str="Research",
                      hours: app_commands.Range[int,0,23]=0, minutes: app_commands.Range[int,0,59]=0):
    timer_id,end_ts=add_timer(interaction.guild_id,player,"research",project,days,hours,minutes,interaction.user.id)
    await interaction.response.send_message(f"Added **#{timer_id} {player}** — {project} — ends <t:{end_ts}:R>.",ephemeral=True); await refresh_board(interaction.guild_id)


@app_commands.guild_only()
@bot.tree.command(name="helpers", description="Show the current helper priority list.")
async def helpers(interaction: discord.Interaction):
    await interaction.response.send_message(embed=make_board_embed(interaction.guild_id))


@app_commands.guild_only()
@bot.tree.command(name="timers", description="Show all active timers, including below-threshold timers.")
async def timers(interaction: discord.Interaction):
    rows=all_active_rows(interaction.guild_id)
    if not rows: await interaction.response.send_message("No active timers.",ephemeral=True); return
    text="\n".join(f"{priority_text(r['priority'])} **#{r['id']}** {r['player']} · {r['timer_type'].title()} · {r['project']} · {human_remaining(r['end_ts'])}" for r in rows)
    await interaction.response.send_message(text[:1900],ephemeral=True)


@app_commands.guild_only()
@bot.tree.command(name="priority", description="Set a timer's helper priority.")
@app_commands.choices(level=[app_commands.Choice(name="URGENT",value=4),app_commands.Choice(name="HIGH",value=3),app_commands.Choice(name="NORMAL",value=2),app_commands.Choice(name="LOW",value=1)])
async def priority(interaction: discord.Interaction, timer_id: int, level: app_commands.Choice[int]):
    with connect() as db:
        row=db.execute("SELECT * FROM timers WHERE id=? AND guild_id=?",(timer_id,interaction.guild_id)).fetchone()
        if not row: await interaction.response.send_message("I couldn't find that timer.",ephemeral=True); return
        if not row_accessible(interaction,row): await interaction.response.send_message("You can only prioritize your own timers. Managers can change any.",ephemeral=True); return
        db.execute("UPDATE timers SET priority=? WHERE id=?",(level.value,timer_id))
    await interaction.response.send_message(f"**#{timer_id} {row['player']}** → {priority_text(level.value)}",ephemeral=True); await refresh_board(interaction.guild_id)


@app_commands.guild_only()
@bot.tree.command(name="updatetime", description="Update remaining time on a timer.")
async def updatetime(interaction: discord.Interaction, timer_id:int, days:app_commands.Range[int,0,3650], hours:app_commands.Range[int,0,23]=0, minutes:app_commands.Range[int,0,59]=0):
    with connect() as db:
        row=db.execute("SELECT * FROM timers WHERE id=? AND guild_id=?",(timer_id,interaction.guild_id)).fetchone()
        if not row: await interaction.response.send_message("I couldn't find that timer.",ephemeral=True); return
        if not row_accessible(interaction,row): await interaction.response.send_message("You can only update your own timers.",ephemeral=True); return
        new_end_ts=int((datetime.now(timezone.utc)+timedelta(days=days,hours=hours,minutes=minutes)).timestamp())
        db.execute("UPDATE timers SET end_ts=?,completed=0 WHERE id=?",(new_end_ts,timer_id))
    await interaction.response.send_message(f"Updated **#{timer_id}** to **{days}d {hours}h {minutes}m** remaining.",ephemeral=True); await refresh_board(interaction.guild_id)


@app_commands.guild_only()
@bot.tree.command(name="done", description="Mark a timer complete.")
async def done(interaction: discord.Interaction, timer_id:int):
    with connect() as db:
        row=db.execute("SELECT * FROM timers WHERE id=? AND guild_id=?",(timer_id,interaction.guild_id)).fetchone()
        if not row: await interaction.response.send_message("I couldn't find that timer.",ephemeral=True); return
        if not row_accessible(interaction,row): await interaction.response.send_message("You can only finish your own timers.",ephemeral=True); return
        db.execute("UPDATE timers SET completed=1 WHERE id=?",(timer_id,))
    await interaction.response.send_message(f"Timer **#{timer_id}** marked complete.",ephemeral=True); await refresh_board(interaction.guild_id)


@app_commands.guild_only()
@bot.tree.command(name="remove", description="Permanently delete a timer.")
async def remove(interaction: discord.Interaction, timer_id:int):
    with connect() as db:
        row=db.execute("SELECT * FROM timers WHERE id=? AND guild_id=?",(timer_id,interaction.guild_id)).fetchone()
        if not row: await interaction.response.send_message("I couldn't find that timer.",ephemeral=True); return
        if not row_accessible(interaction,row): await interaction.response.send_message("You can only delete your own timers.",ephemeral=True); return
        db.execute("DELETE FROM timers WHERE id=?",(timer_id,))
    await interaction.response.send_message(f"Timer **#{timer_id}** permanently deleted.",ephemeral=True); await refresh_board(interaction.guild_id)


@app_commands.guild_only()
@bot.tree.command(name="stats", description="Show a quick Bob helper-board summary.")
async def stats(interaction: discord.Interaction):
    now=int(datetime.now(timezone.utc).timestamp())
    with connect() as db:
        active=db.execute("SELECT COUNT(*) c FROM timers WHERE guild_id=? AND completed=0 AND end_ts>?",(interaction.guild_id,now)).fetchone()["c"]
        builds=db.execute("SELECT COUNT(*) c FROM timers WHERE guild_id=? AND completed=0 AND timer_type='build' AND end_ts>?",(interaction.guild_id,now)).fetchone()["c"]
        research=db.execute("SELECT COUNT(*) c FROM timers WHERE guild_id=? AND completed=0 AND timer_type='research' AND end_ts>?",(interaction.guild_id,now)).fetchone()["c"]
        urgent=db.execute("SELECT COUNT(*) c FROM timers WHERE guild_id=? AND completed=0 AND priority=4 AND end_ts>?",(interaction.guild_id,now)).fetchone()["c"]
    await interaction.response.send_message(f"**Bob Stats**\nActive: **{active}** · Builds: **{builds}** · Research: **{research}** · Urgent: **{urgent}**",ephemeral=True)


@app_commands.guild_only()
@bot.tree.command(name="cleanup", description="Delete completed and expired timers from Bob's database.")
@app_commands.checks.has_permissions(manage_guild=True)
async def cleanup(interaction: discord.Interaction):
    now=int(datetime.now(timezone.utc).timestamp())
    with connect() as db:
        cur=db.execute("DELETE FROM timers WHERE guild_id=? AND (completed=1 OR end_ts<=?)",(interaction.guild_id,now)); n=cur.rowcount
    await interaction.response.send_message(f"Cleaned up **{n}** completed/expired timer(s).",ephemeral=True); await refresh_board(interaction.guild_id)


@app_commands.guild_only()
@bot.tree.command(name="board", description="Create/move the auto-updating helper board to this channel.")
@app_commands.checks.has_permissions(manage_guild=True)
async def board(interaction: discord.Interaction):
    await interaction.response.defer(ephemeral=True)
    message=await interaction.channel.send(embed=make_board_embed(interaction.guild_id),view=HelperButtons())
    with connect() as db:
        db.execute("""INSERT INTO boards(guild_id,channel_id,message_id) VALUES(?,?,?)
                    ON CONFLICT(guild_id) DO UPDATE SET channel_id=excluded.channel_id,message_id=excluded.message_id""",
                   (interaction.guild_id,interaction.channel_id,message.id))
    await interaction.followup.send("Bob's auto-updating priority board is live in this channel.",ephemeral=True)


@app_commands.guild_only()
@bot.tree.command(name="seedcurrent", description="Load the supplied 9/10 build/research list.")
@app_commands.checks.has_permissions(manage_guild=True)
async def seedcurrent(interaction: discord.Interaction):
    with connect() as db:
        count=db.execute("SELECT COUNT(*) c FROM timers WHERE guild_id=?",(interaction.guild_id,)).fetchone()["c"]
        if count: await interaction.response.send_message("This server already has timers, so I didn't create duplicates.",ephemeral=True); return
        seed_start=datetime(2026,9,10,17,41,tzinfo=timezone.utc)
        entries=[("B3ndm3ov3r","build","Power Plant",11),("Tomcat","build","Power Plant",24),("GabrielValeriote","build","Power Plant",14),("Kickflip","build","Power Plant",19),("Advent","build","Power Plant",18),("Winry","build","Construction",22),("Winry","research","Research Timer 1",55),("Winry","research","Research Timer 2",19)]
        created_ts=int(datetime.now(timezone.utc).timestamp())
        for player,timer_type,project,days in entries:
            end_ts=int((seed_start+timedelta(days=days)).timestamp())
            db.execute("INSERT INTO timers(guild_id,player,timer_type,project,end_ts,created_by,created_ts,priority) VALUES(?,?,?,?,?,?,?,2)",(interaction.guild_id,player,timer_type,project,end_ts,interaction.user.id,created_ts))
    await interaction.response.send_message("Loaded the 9/10 helper list with NORMAL priority.",ephemeral=True); await refresh_board(interaction.guild_id)


@board.error
@cleanup.error
@seedcurrent.error
async def admin_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
    if isinstance(error, app_commands.MissingPermissions):
        msg="You need **Manage Server** permission for that command."
        if interaction.response.is_done(): await interaction.followup.send(msg,ephemeral=True)
        else: await interaction.response.send_message(msg,ephemeral=True)
    else: raise error


@tasks.loop(minutes=REFRESH_MINUTES)
async def auto_refresh():
    with connect() as db: guild_ids=[r["guild_id"] for r in db.execute("SELECT guild_id FROM boards").fetchall()]
    for guild_id in guild_ids:
        await refresh_board(guild_id); await asyncio.sleep(1)


@auto_refresh.before_loop
async def before_auto_refresh(): await bot.wait_until_ready()


@bot.event
async def on_ready():
    print(f"Logged in as {bot.user} (ID: {bot.user.id})")
    if not auto_refresh.is_running(): auto_refresh.start()


if __name__ == "__main__":
    if not TOKEN: raise RuntimeError("DISCORD_TOKEN is missing. Copy .env.example to .env and paste your bot token.")
    bot.run(TOKEN)
